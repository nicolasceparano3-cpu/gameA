// Tiny synthesized foley — no external assets, everything built from noise + sine.
let ctx: AudioContext | null = null;
let noise: AudioBuffer | null = null;
let master: GainNode | null = null;

export function initAudio() {
  if (typeof window === "undefined") return;
  if (!ctx) {
    const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    ctx = new AC();
    master = ctx.createGain();
    master.gain.value = 0.5;
    master.connect(ctx.destination);
    const len = Math.floor(ctx.sampleRate * 0.6);
    noise = ctx.createBuffer(1, len, ctx.sampleRate);
    const d = noise.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
  }
  if (ctx.state === "suspended") void ctx.resume();
}

export function setVolume(v: number) {
  if (master) master.gain.value = v;
}

function burst(freq: number, q: number, dur: number, gain: number, delay = 0) {
  if (!ctx || !noise || !master) return;
  const t = ctx.currentTime + delay;
  const src = ctx.createBufferSource();
  src.buffer = noise;
  const bp = ctx.createBiquadFilter();
  bp.type = "bandpass";
  bp.frequency.value = freq;
  bp.Q.value = q;
  const g = ctx.createGain();
  g.gain.setValueAtTime(gain, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  src.connect(bp).connect(g).connect(master);
  src.start(t);
  src.stop(t + dur + 0.02);
}

function tone(f0: number, f1: number, dur: number, gain: number, type: OscillatorType = "sine", delay = 0) {
  if (!ctx || !master) return;
  const t = ctx.currentTime + delay;
  const o = ctx.createOscillator();
  o.type = type;
  o.frequency.setValueAtTime(f0, t);
  o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
  const g = ctx.createGain();
  g.gain.setValueAtTime(gain, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(master);
  o.start(t);
  o.stop(t + dur + 0.02);
}

export type SoundKind = "hit" | "block" | "parry" | "clash" | "stumble" | "fall" | "step" | "whoosh" | "break";

export function play(kind: SoundKind, power = 8) {
  if (!ctx) initAudio();
  if (!ctx) return;
  const p = Math.min(1.6, power / 10);
  switch (kind) {
    case "hit":
      burst(1500 - p * 500, 1.1, 0.1 + p * 0.05, 0.35 + p * 0.3);
      tone(150 + p * 40, 48, 0.16 + p * 0.1, 0.5 + p * 0.35);
      burst(320, 2.4, 0.09, 0.22);
      break;
    case "block":
      burst(900, 1.6, 0.07, 0.3);
      tone(320, 190, 0.08, 0.24, "triangle");
      break;
    case "parry":
      burst(2400, 3.5, 0.1, 0.24);
      tone(1750, 1400, 0.24, 0.2, "sine");
      tone(2600, 2300, 0.18, 0.1, "sine", 0.02);
      break;
    case "clash":
      burst(2000, 2.2, 0.13, 0.3);
      tone(600, 300, 0.14, 0.28, "square");
      break;
    case "break":
      burst(700, 0.8, 0.3, 0.42);
      tone(220, 60, 0.4, 0.4, "sawtooth");
      break;
    case "stumble":
      burst(420, 1.2, 0.18, 0.26);
      tone(180, 90, 0.22, 0.26);
      break;
    case "fall":
      burst(260, 0.7, 0.4, 0.5);
      tone(110, 38, 0.5, 0.55);
      break;
    case "step":
      burst(600, 0.9, 0.06, 0.1);
      break;
    case "whoosh":
      burst(1100, 0.6, 0.13, 0.12);
      break;
  }
}
