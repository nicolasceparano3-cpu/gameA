// ── Opponent intent: same pose system the player uses, chosen by personality ──
import { clamp, clonePose, type Pose } from "./pose";
import type { MoveTag, Plan, Sim, Fighter } from "./engine";
import type { Opponent } from "./content";

const rr =
  (r: () => number, n: number) =>
  () =>
    (r() * 2 - 1) * n;

type Tpl = (b: Pose, r: () => number) => Pose;

const j = rr;

const TEMPLATES: Record<string, Tpl> = {
  jab: (b, r) => ({
    ...clonePose(b),
    lean: 0.26,
    twist: 0.36,
    crouch: 0.24,
    weight: 0.5,
    handN: { x: 68 + j(r, 6)(), y: 134 + j(r, 7)() },
    handF: { x: 18, y: 130 },
    footN: { x: 28, y: 0 },
    footF: { x: -28, y: 0 },
    kindN: "fist",
    kindF: "fist",
  }),
  cross: (b, r) => ({
    ...clonePose(b),
    lean: 0.34,
    twist: -0.42,
    crouch: 0.3,
    weight: 0.6,
    handN: { x: 26, y: 120 },
    handF: { x: 72 + j(r, 6)(), y: 132 + j(r, 8)() },
    footN: { x: 30, y: 0 },
    footF: { x: -30, y: 0 },
    kindN: "fist",
    kindF: "fist",
  }),
  body: (b, r) => ({
    ...clonePose(b),
    lean: 0.32,
    twist: -0.3,
    crouch: 0.46,
    weight: 0.55,
    handN: { x: 28, y: 118 },
    handF: { x: 64 + j(r, 6)(), y: 96 + j(r, 6)() },
    footN: { x: 30, y: 0 },
    footF: { x: -32, y: 0 },
    kindN: "fist",
    kindF: "fist",
  }),
  palmPush: (b, r) => ({
    ...clonePose(b),
    lean: 0.3,
    twist: -0.2,
    crouch: 0.32,
    weight: 0.66,
    handN: { x: 30, y: 122 },
    handF: { x: 66 + j(r, 5)(), y: 106 + j(r, 6)() },
    footN: { x: 32, y: 0 },
    footF: { x: -30, y: 0 },
    kindN: "palm",
    kindF: "palm",
  }),
  guardHigh: (b) => ({
    ...clonePose(b),
    lean: 0.04,
    twist: 0.2,
    crouch: 0.38,
    weight: -0.28,
    handN: { x: 26, y: 146 },
    handF: { x: 20, y: 150 },
    footN: { x: 24, y: 0 },
    footF: { x: -30, y: 0 },
    kindN: "palm",
    kindF: "palm",
  }),
  parry: (b) => ({
    ...clonePose(b),
    lean: 0.02,
    twist: 0.1,
    crouch: 0.3,
    weight: -0.08,
    handN: { x: 44, y: 130 },
    handF: { x: 20, y: 136 },
    footN: { x: 26, y: 0 },
    footF: { x: -28, y: 0 },
    kindN: "palm",
    kindF: "palm",
  }),
  lowKick: (b, r) => ({
    ...clonePose(b),
    lean: -0.2,
    twist: 0.2,
    crouch: 0.32,
    weight: -0.5,
    handN: { x: 22, y: 124 },
    handF: { x: 14, y: 132 },
    footN: { x: 66 + j(r, 8)(), y: 30 + j(r, 6)() },
    footF: { x: -24, y: 0 },
    kindN: "fist",
    kindF: "fist",
  }),
  highKick: (b, r) => ({
    ...clonePose(b),
    lean: -0.26,
    twist: 0.2,
    crouch: 0.24,
    weight: -0.55,
    handN: { x: 24, y: 126 },
    handF: { x: 12, y: 134 },
    footN: { x: 44, y: 0 },
    footF: { x: 58 + j(r, 8)(), y: 118 + j(r, 10)() },
    kindN: "fist",
    kindF: "fist",
  }),
  sweep: (b, r) => ({
    ...clonePose(b),
    lean: -0.3,
    twist: 0.3,
    crouch: 0.62,
    weight: -0.45,
    handN: { x: 30, y: 106 },
    handF: { x: 8, y: 118 },
    footN: { x: 34, y: 0 },
    footF: { x: 62 + j(r, 8)(), y: 14 },
    kindN: "palm",
    kindF: "palm",
  }),
  slipBack: (b) => ({
    ...clonePose(b),
    lean: -0.24,
    twist: 0.24,
    crouch: 0.3,
    weight: -0.55,
    handN: { x: 30, y: 140 },
    handF: { x: 22, y: 144 },
    footN: { x: 18, y: 0 },
    footF: { x: -40, y: 0 },
    kindN: "palm",
    kindF: "fist",
  }),
  stepIn: (b) => ({
    ...clonePose(b),
    lean: 0.24,
    twist: 0.2,
    crouch: 0.32,
    weight: 0.5,
    handN: { x: 34, y: 138 },
    handF: { x: 26, y: 142 },
    footN: { x: 40, y: 0 },
    footF: { x: -14, y: 0 },
    kindN: "palm",
    kindF: "fist",
  }),
  grab: (b, r) => ({
    ...clonePose(b),
    lean: 0.28,
    twist: 0.1,
    crouch: 0.42,
    weight: 0.6,
    handN: { x: 58 + j(r, 6)(), y: 110 },
    handF: { x: 56 + j(r, 6)(), y: 116 },
    footN: { x: 36, y: 0 },
    footF: { x: -24, y: 0 },
    kindN: "palm",
    kindF: "palm",
  }),
  hold: (b) => clonePose(b),
};

const DESIRED: Record<string, number> = {
  jab: 62,
  cross: 64,
  body: 58,
  palmPush: 60,
  lowKick: 82,
  highKick: 86,
  sweep: 74,
  grab: 44,
  stepIn: 56,
  slipBack: 150,
  guardHigh: 130,
  parry: 120,
  hold: 1e3,
};

const COUNTERS: Record<string, string[]> = {
  jab: ["parry", "slipBack"],
  cross: ["slipBack", "parry"],
  body: ["guardHigh", "slipBack"],
  palmPush: ["stepIn", "grab"],
  lowKick: ["stepIn", "parry"],
  highKick: ["stepIn", "slipBack"],
  sweep: ["stepIn"],
  guardHigh: ["body", "lowKick"],
  parry: ["body", "lowKick"],
  grab: ["slipBack"],
  slipBack: ["stepIn", "cross"],
  stepIn: ["parry", "cross"],
  hold: ["jab", "body"],
};

function pick<T>(arr: T[], r: () => number): T {
  return arr[Math.floor(r() * arr.length) % arr.length];
}

function suitability(tag: string, dist: number, f: Fighter, o: Opponent): number {
  const want = DESIRED[tag] ?? 1e3;
  if (want > 900) return 0.55;
  const err = Math.abs(dist - want);
  let score = clamp(1.35 - err / 90, 0.05, 1.35);
  if (tag === "lowKick" || tag === "highKick" || tag === "sweep") score *= o.p.kickUse * 1.6 + 0.15;
  if (tag === "parry" || tag === "guardHigh" || tag === "palmPush") score *= o.p.palmUse * 1.5 + 0.2;
  if (tag === "slipBack") score *= o.p.headMovement * 1.3 + 0.2;
  if (f.sta < 30 && (tag === "stepIn" || tag === "cross")) score *= 0.55;
  if (f.bal < 38 && (tag === "lowKick" || tag === "highKick" || tag === "sweep")) score *= 0.35;
  if (f.grd < 30 && tag !== "guardHigh" && tag !== "slipBack") score *= 0.7;
  return score;
}

function weighted(tags: string[], w: (t: string) => number, r: () => number): string {
  const total = tags.reduce((s, t) => s + Math.max(0.001, w(t)), 0);
  let x = r() * total;
  for (const t of tags) {
    x -= Math.max(0.001, w(t));
    if (x <= 0) return t;
  }
  return tags[tags.length - 1];
}

export function planAI(s: Sim, self: Fighter, target: Fighter, o: Opponent, r: () => number): Plan {
  const distRaw = Math.abs(target.cur.x - self.cur.x);
  const dist = s.active.p.has("afterimage") && s.decoy ? Math.abs(s.decoy.x - self.cur.x) : distRaw;
  const P = o.p;
  const aggressive = P.aggression;

  // ── habit reading (Master and above) ────────────────────────────────────
  let forced: string | null = null;
  if (P.predict > 0.4 && s.habits.length >= 3) {
    const recent = s.habits.slice(-5);
    const counts: Record<string, number> = {};
    for (const h of recent) counts[h] = (counts[h] || 0) + 1;
    const top = Object.entries(counts).sort((a, b) => b[1] - a[1])[0];
    if (top && top[1] >= 2 && r() < P.predict) {
      const c = COUNTERS[top[0]];
      if (c) forced = pick(c, r);
    }
  }

  const pressure = target.stagger > 8 || target.bal < 36 || target.grd < 25;
  const hurt = self.bal < 38 || self.grd < 26 || self.sta < 24;

  let tag: string;
  if (forced) tag = forced;
  else if (hurt && r() < 0.72) tag = r() < 0.5 ? "slipBack" : "guardHigh";
  else if (distRaw > 165) tag = "stepIn";
  else if (pressure && r() < 0.78) tag = weighted(o.roster, (t) => suitability(t, dist, self, o) * (t === "hold" ? 0.2 : 1.6), r);
  else if (r() < aggressive) tag = weighted(o.roster, (t) => suitability(t, dist, self, o) * (t === "hold" ? 0.4 : 1.2), r);
  else tag = weighted([...o.roster, "hold", "parry", "guardHigh"], (t) => suitability(t, dist, self, o) * (t === "hold" ? 1.1 : 0.9), r);

  if (tag === "hold" && r() < 0.5) tag = "guardHigh";

  const tpl = TEMPLATES[tag] || TEMPLATES.hold;
  const pose = tpl(self.cur, r);

  // ── root motion ────────────────────────────────────────────────────────
  const want = DESIRED[tag] ?? dist;
  const dir = Math.sign((s.decoy ? s.decoy.x : target.cur.x) - self.cur.x) || self.facing;
  const maxStep = 34 + self.sta * 0.34 + (tag === "stepIn" ? 26 : 0) + P.advance * 22;
  let stepW = dir * clamp(dist - want, -maxStep, maxStep);
  if (tag === "hold" || tag === "guardHigh" || tag === "parry") {
    // hold ground, drift only slightly
    stepW *= 0.25;
    if (r() < 0.4) stepW = 0;
  }
  pose.x = clamp(self.cur.x + stepW, 90, 1110);

  const tempo = clamp(0.86 + aggressive * 0.3 + (pressure ? 0.14 : 0) + (r() - 0.5) * 0.16, 0.7, 1.35);
  return { pose, tempo, tag: tag as MoveTag };
}

/** What the player's own pose edit means, expressed as a move tag. */
export function holdPlan(cur: Pose): Plan {
  return { pose: clonePose(cur), tempo: 0.9, tag: "hold" };
}

export { TEMPLATES };
