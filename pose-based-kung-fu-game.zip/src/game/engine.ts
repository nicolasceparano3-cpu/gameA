// ── Deterministic 60Hz combat simulation ──────────────────────────────────
import {
  clamp,
  clonePose,
  commitAmount,
  interpolatePose,
  lerp,
  neutralPose,
  rig,
  stanceBase,
  worldRig,
  type Pose,
  type Pt,
} from "./pose";
import { ZONES, type ZoneId } from "./content";

export type MoveTag =
  | "jab"
  | "cross"
  | "body"
  | "palmPush"
  | "lowKick"
  | "highKick"
  | "guardHigh"
  | "parry"
  | "slipBack"
  | "stepIn"
  | "grab"
  | "sweep"
  | "hold";

export interface Plan {
  pose: Pose;
  tempo: number;
  tag: MoveTag;
}

export interface Ev {
  kind: "hit" | "block" | "parry" | "clash" | "stumble" | "fall" | "push" | "whiff" | "break";
  side: 0 | 1; // who it happened TO
  zone: ZoneId | "none";
  power: number;
  x: number;
  y: number;
  text: string;
  heavy: boolean;
}

export interface Frame {
  a: Pose;
  b: Pose;
  evs: Ev[];
  shake: number;
  hp: [number, number];
  bal: [number, number];
}

export interface Fighter {
  id: 0 | 1;
  name: string;
  cn: string;
  accent: string;
  facing: 1 | -1;
  from: Pose;
  target: Pose;
  cur: Pose;
  p: number;
  dur: number;
  startedAt: number; // tick offset (FIRST WORD)
  hp: number;
  sta: number;
  bal: number;
  grd: number;
  vel: number;
  vy: number;
  stagger: number;
  down: number;
  recovering: number;
  hitLag: number;
  spin: number; // rotational impulse that survives pose recomputation
  flash: number;
  blockFlash: number;
  parryFlash: number;
  cloth: Pt[];
  hair: Pt[];
  prevN: Pt;
  prevF: Pt;
  prevFootN: Pt;
  prevFootF: Pt;
  weakN: number;
  weakF: number;
  counterWin: number;
  hitTags: string[];
  guardIntro: number;
  tag: MoveTag;
}

export interface Sim {
  f: [Fighter, Fighter];
  tick: number;
  turn: number;
  turnStart: number;
  events: Ev[];
  shake: number;
  hitStop: number;
  log: Frame[];
  habits: string[];
  aiHabits: string[];
  active: { p: Set<string>; o: Set<string> };
  hitSet: Set<string>;
  decoy: { x: number; y: number } | null;
  carry: number;
  secondThoughtUsed: boolean;
  pausedForThought: boolean;
  ended: boolean;
  winner: 0 | 1 | null;
  mode: string;
  seed: number;
}

const TAU = Math.PI * 2;
function mulberry(seed: number) {
  let a = seed >>> 0;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export const STAGE = { left: 70, right: 1130 };

export function makeFighter(id: 0 | 1, name: string, cn: string, accent: string, facing: 1 | -1, x: number): Fighter {
  const base = neutralPose(x, 0.26);
  return {
    id,
    name,
    cn,
    accent,
    facing,
    from: clonePose(base),
    target: clonePose(base),
    cur: clonePose(base),
    p: 1,
    dur: 46,
    startedAt: 0,
    hp: 100,
    sta: 100,
    bal: 82,
    grd: 100,
    vel: 0,
    vy: 0,
    stagger: 0,
    down: 0,
    recovering: 0,
    hitLag: 0,
    spin: 0,
    flash: 0,
    blockFlash: 0,
    parryFlash: 0,
    cloth: [],
    hair: [],
    prevN: { x: 0, y: 0 },
    prevF: { x: 0, y: 0 },
    prevFootN: { x: 0, y: 0 },
    prevFootF: { x: 0, y: 0 },
    weakN: 0,
    weakF: 0,
    counterWin: 0,
    hitTags: [],
    guardIntro: 0,
    tag: "hold",
  };
}

export function newSim(mode: string, oppName: string, oppCn: string, oppAccent: string, seed = Date.now()): Sim {
  const rnd = mulberry(seed);
  void rnd;
  const a = makeFighter(0, "YOU", "你", "#C1272D", 1, 505);
  const b = makeFighter(1, oppName, oppCn, oppAccent, -1, 695);
  for (const f of [a, b]) {
    const rw = worldRig(f.cur, f.facing);
    f.prevN = rw.hdN;
    f.prevF = rw.hdF;
    f.prevFootN = rw.ftN;
    f.prevFootF = rw.ftF;
  }
  return {
    f: [a, b],
    tick: 0,
    turn: 1,
    turnStart: 0,
    events: [],
    shake: 0,
    hitStop: 0,
    log: [],
    habits: [],
    aiHabits: [],
    active: { p: new Set(), o: new Set() },
    hitSet: new Set(),
    decoy: null,
    carry: 0,
    secondThoughtUsed: false,
    pausedForThought: false,
    ended: false,
    winner: null,
    mode,
    seed,
  };
}

/** Cloth + hair: world-space verlet strands pinned to the body. */
function initStrands(f: Fighter) {
  const r = rig(f.cur);
  const pelvis = { x: f.cur.x + f.facing * r.pelvis.x, y: r.pelvis.y + f.cur.lift };
  const head = { x: f.cur.x + f.facing * r.head.x, y: r.head.y + f.cur.lift };
  f.cloth = [0, 1, 2, 3].map((i) => ({ x: pelvis.x - f.facing * i * 6, y: pelvis.y - i * 12 }));
  f.hair = [0, 1, 2, 3].map((i) => ({ x: head.x - f.facing * (9 + i * 7), y: head.y + 6 - i * 3 }));
}

function stepStrand(pts: Pt[], pin: Pt, facing: number, drag: number, len: number, inertia: number) {
  if (!pts.length) return;
  pts[0].x = pin.x;
  pts[0].y = pin.y;
  for (let i = 1; i < pts.length; i++) {
    const p = pts[i];
    const sx = p.x;
    const sy = p.y;
    const vx = (p.x - (p as any).ox) * drag;
    const vy = (p.y - (p as any).oy) * drag;
    (p as any).ox = sx;
    (p as any).oy = sy;
    p.x += vx;
    p.y += vy - 0.85;
    p.x -= facing * inertia;
    // distance constraint to previous
    const dx = p.x - pts[i - 1].x;
    const dy = p.y - pts[i - 1].y;
    const d = Math.hypot(dx, dy) || 0.001;
    const diff = (d - len) / d;
    p.x -= dx * diff;
    p.y -= dy * diff;
  }
}

function updateStrands(f: Fighter, prevX: number) {
  if (!f.cloth.length) {
    initStrands(f);
    return;
  }
  const r = rig(f.cur);
  const pelvis = { x: f.cur.x + f.facing * r.pelvis.x, y: r.pelvis.y + f.cur.lift };
  const head = { x: f.cur.x + f.facing * r.head.x, y: r.head.y + f.cur.lift };
  const inertia = clamp((f.cur.x - prevX) * f.facing, -14, 14) * 0.9;
  const drag = 0.86;
  stepStrand(f.cloth, pelvis, f.facing, drag, 13, inertia * 0.7);
  stepStrand(f.hair, head, f.facing, drag, 8, inertia);
}

// ── helpers ────────────────────────────────────────────────────────────────
function stanceFactor(f: Fighter) {
  return clamp(stanceBase(f.cur) * 0.85, 20, 95);
}

function contactPower(s: Sim, A: Fighter, speed: number, isFoot: boolean, kind: string) {
  const commit = commitAmount(A.from, A.target) * (s.active.p.has("flowing") && A.id === 0 ? 1.3 : 1);
  const velF = clamp(speed / 6.2, 0, 1.5);
  const bodyF = 0.6 + 0.36 * clamp(commit, 0, 1.6);
  const staF = A.sta < 24 ? 0.66 : 1;
  const weakF = 1;
  const base = kind === "palm" ? 7.4 : isFoot ? 8.6 : 8.4;
  const tempo = 0.92 + 0.2 * (A.tag === "hold" ? 0 : 1);
  return base * (0.44 + 0.95 * velF) * bodyF * staF * weakF * tempo;
}

interface Contact {
  attacker: Fighter;
  defender: Fighter;
  point: Pt;
  zone: ZoneId;
  kind: "fist" | "palm" | "foot";
  vel: number;
  dir: number;
  isHand: boolean;
  isFoot: boolean;
  which: "N" | "F";
  power: number;
  precise: number; // 0..1 how centred the strike was (pressure point)
}

function handVel(f: Fighter, which: "N" | "F") {
  return which === "N" ? f.prevN : f.prevF;
}

/** Displace a fighter and move their planned end-position with it, so the
 *  root spring carries the push instead of quietly undoing it. */
function pushBy(f: Fighter, amt: number) {
  if (!amt) return;
  const nx = clamp(f.cur.x + amt, STAGE.left, STAGE.right);
  const shift = nx - f.cur.x;
  f.cur.x = nx;
  f.target.x = clamp(f.target.x + shift, STAGE.left, STAGE.right);
  f.vel += shift * 0.1;
}

/** Which of the defender's limbs, if any, is covering this contact point. */
function guardAt(d: Fighter, point: Pt): { which: "N" | "F"; dist: number; kind: "fist" | "palm" } | null {
  const rw = worldRig(d.cur, d.facing);
  const a = { p: rw.hdN, k: d.cur.kindN };
  const b = { p: rw.hdF, k: d.cur.kindF };
  const ra = a.k === "palm" ? 27 : 21;
  const rb = b.k === "palm" ? 27 : 21;
  const da = Math.hypot(a.p.x - point.x, a.p.y - point.y);
  const db = Math.hypot(b.p.x - point.x, b.p.y - point.y);
  if (da < ra && da <= db) return { which: "N", dist: da, kind: a.k };
  if (db < rb) return { which: "F", dist: db, kind: b.k };
  return null;
}

function contactPointOK(_s: Sim, a: Fighter, b: Fighter, hp: Pt, isFoot: boolean): { zone: ZoneId; point: Pt; d: number } | null {
  void a;
  void _s;
  const rw = worldRig(b.cur, b.facing);
  const zones: { id: ZoneId; a: Pt; bb: Pt; r: number }[] = [
    { id: "head", a: rw.head, bb: rw.head, r: 16 },
    { id: "torso", a: rw.neck, bb: rw.pelvis, r: 15 },
    { id: "arm", a: rw.shF, bb: rw.hdF, r: 11 },
    { id: "leg", a: rw.hipF, bb: rw.knF, r: 12 },
    { id: "leg", a: rw.knF, bb: rw.ftF, r: 11 },
    { id: "leg", a: rw.hipN, bb: rw.knN, r: 12 },
    { id: "leg", a: rw.knN, bb: rw.ftN, r: 11 },
  ];
  const handR = isFoot ? 12 : 9;
  let best: { zone: ZoneId; point: Pt; d: number } | null = null;
  for (const z of zones) {
    const dx = z.bb.x - z.a.x;
    const dy = z.bb.y - z.a.y;
    const l2 = dx * dx + dy * dy || 1e-6;
    let t = ((hp.x - z.a.x) * dx + (hp.y - z.a.y) * dy) / l2;
    t = clamp(t, 0, 1);
    const cx = z.a.x + dx * t;
    const cy = z.a.y + dy * t;
    const d = Math.hypot(hp.x - cx, hp.y - cy);
    const reach = z.r + handR;
    if (d < reach && (!best || d < best.d)) best = { zone: z.id, point: { x: cx, y: cy }, d };
  }
  void a;
  return best;
}

function push(s: Sim, ev: Ev) {
  s.events.push(ev);
}

function heavyPower(p: number) {
  return p > 9;
}

/** Apply one physical contact. */
export function resolveContact(s: Sim, c: Contact, prevTurnHits: Set<string>) {
  const A = c.attacker;
  const D = c.defender;
  const key = `${A.id}:${c.which}:${c.isFoot ? "ft" : "hd"}`;
  if (prevTurnHits.has(key)) return;

  const isPalm = c.kind === "palm";
  const isFoot = c.kind === "foot";
  const dir = A.facing;

  // ── guard?
  const g = isFoot ? null : guardAt(D, c.point);
  const canGuard = D.down === 0 && D.stagger < 14 && D.grd > 0 && c.vel > 0.4;
  if (g && canGuard) {
    prevTurnHits.add(key);
    const incomingSpeed = c.vel;
    const palm = g.kind === "palm";
    const iron = s.active.p.has("iron") && D.id === 0 && palm ? 1.55 : 1;
    // a palm meeting the strike squarely, with the defender moving into it, is a parry
    const guardVel = Math.abs(handVel(D, g.which).x) + Math.abs(handVel(D, g.which).y);
    const parry = palm && (incomingSpeed > 2.6 || guardVel > 3.4) && g.dist < 18;
    const absorb = (palm ? 0.84 : 0.52) * iron;
    const power = c.power * (1 - absorb);

    if (parry) {
      D.parryFlash = 14;
      A.stagger = Math.max(A.stagger, 16 + Math.round(c.power * 0.7));
      pushBy(A, -dir * c.power * 1.5);
      A.spin -= A.facing * 0.26;
      D.counterWin = 34;
      D.bal = clamp(D.bal + 4, 0, 100);
      push(s, {
        kind: "parry",
        side: A.id,
        zone: c.zone,
        power: c.power,
        x: c.point.x,
        y: c.point.y,
        text: "PARRY",
        heavy: c.power > 11,
      });
      if (s.active.p.has("counter") && D.id === 0) {
        pushBy(A, -dir * c.power * 1.7);
        A.bal = clamp(A.bal - c.power * 0.7, 0, 100);
        push(s, { kind: "push", side: A.id, zone: c.zone, power: c.power, x: c.point.x, y: c.point.y, text: "順勢 COUNTERFLOW", heavy: false });
      }
      s.shake = Math.max(s.shake, 5);
      s.hitStop = Math.max(s.hitStop, 5);
      return;
    }

    // plain block — guard pressure, small chip, attacker gets deflected
    D.grd = clamp(D.grd - c.power * (palm ? 1.75 : 2.9), 0, 100);
    D.blockFlash = 12;
    if (D.grd <= 0.01) {
      prevTurnHits.add(key);
      push(s, { kind: "break", side: D.id, zone: c.zone, power: c.power, x: c.point.x, y: c.point.y, text: "GUARD BROKEN", heavy: true });
      D.stagger = Math.max(D.stagger, 20);
      D.hp = clamp(D.hp - c.power * 1.5, 0, 100);
      D.bal = clamp(D.bal - c.power * 1.1, 0, 100);
      D.grd = 6;
      s.shake = Math.max(s.shake, 7);
      s.hitStop = Math.max(s.hitStop, 6);
      return;
    }
    D.hp = clamp(D.hp - power * 0.35, 0, 100);
    D.bal = clamp(D.bal - power * 0.5, 0, 100);
    D.sta = clamp(D.sta - c.power * 0.55, 0, 100);
    pushBy(D, dir * c.power * 1.1);
    pushBy(A, -dir * c.power * 1.5);
    A.spin -= A.facing * 0.17;
    A.stagger = Math.max(A.stagger, 6);
    push(s, { kind: "block", side: D.id, zone: c.zone, power: c.power, x: c.point.x, y: c.point.y, text: palm ? "BLOCKED" : "GUARD UP", heavy: false });
    s.shake = Math.max(s.shake, 3);
    s.hitStop = Math.max(s.hitStop, 3);
    return;
  }

  prevTurnHits.add(key);

  // ── clean hit
  const z = ZONES[c.zone];
  const palmStrike = isPalm;
  const scale = (palmStrike ? 0.55 : 1) * (isFoot ? 1.12 : 1);
  let dmg = c.power * z.dmg * 0.85 * scale;
  let balLoss = c.power * z.bal * 0.78;
  const staLoss = c.power * z.sta * 0.62;
  const kb = c.power * z.kb * 0.85 * (palmStrike ? 1.75 : 1) * (s.active.p.has("rooted") && D.id === 0 ? 0.33 : 1);
  const rot = c.power * 0.035 * (c.zone === "head" ? 1.6 : c.zone === "leg" ? 0.7 : 1);

  // pressure point: dead-centre strikes on a joint weaken that limb
  if (s.active.p.has("pressure") && A.id === 0 && c.precise > 0.66) {
    dmg *= 1.35;
    balLoss *= 1.35;
    if (c.zone === "arm" || c.zone === "leg") {
      if (c.which === "N") D.weakN = 90;
      else D.weakF = 90;
    }
    push(s, { kind: "hit", side: D.id, zone: c.zone, power: c.power, x: c.point.x, y: c.point.y, text: "點穴", heavy: false });
  }

  D.hp = clamp(D.hp - dmg, 0, 100);
  D.bal = clamp(D.bal - balLoss, 0, 100);
  D.sta = clamp(D.sta - staLoss, 0, 100);
  pushBy(D, dir * kb * 2.7);
  D.spin += D.facing * rot * (c.zone === "head" ? 1 : -0.5);
  D.stagger = Math.max(D.stagger, Math.round(clamp(c.power * 0.9, 3, 22)));
  D.flash = 9;
  A.counterWin = 0;

  if (palmStrike) {
    push(s, { kind: "push", side: D.id, zone: c.zone, power: c.power, x: c.point.x, y: c.point.y, text: "PALM PUSH", heavy: c.power > 12 });
  } else {
    push(s, {
      kind: "hit",
      side: D.id,
      zone: c.zone,
      power: c.power,
      x: c.point.x,
      y: c.point.y,
      text: z.label,
      heavy: heavyPower(c.power),
    });
  }

  s.shake = Math.max(s.shake, clamp(c.power * 0.55, 2, 11));
  s.hitStop = Math.max(s.hitStop, clamp(Math.round(c.power * 0.42), 2, 8));

  if (D.bal <= 24 && D.down === 0) {
    D.stagger = Math.max(D.stagger, 24);
    push(s, { kind: "stumble", side: D.id, zone: c.zone, power: c.power, x: D.cur.x, y: 40, text: "STUMBLE", heavy: false });
  }
  if (D.bal <= 7 && D.down === 0 && (c.zone === "leg" || c.zone === "head") && c.power > 9.5) {
    D.down = 74;
    D.recovering = 0;
    D.stagger = 0;
    push(s, { kind: "fall", side: D.id, zone: c.zone, power: c.power, x: D.cur.x, y: 20, text: "FALL", heavy: true });
    s.shake = 12;
  }
}

// ── main tick ──────────────────────────────────────────────────────────────
export function step(s: Sim, opts: { sandbox?: boolean; training?: boolean } = {}) {
  s.events = [];
  s.shake *= 0.82;
  if (s.shake < 0.05) s.shake = 0;

  if (s.hitStop > 0) {
    s.hitStop--;
    record(s);
    s.tick++;
    return;
  }

  const done: boolean[] = [];

  for (const f of s.f) {
    if (f.hitLag > 0) f.hitLag--;
    if (f.flash > 0) f.flash--;
    if (f.blockFlash > 0) f.blockFlash--;
    if (f.parryFlash > 0) f.parryFlash--;
    if (f.stagger > 0) f.stagger--;
    if (f.counterWin > 0) f.counterWin--;
    if (f.weakN > 0) f.weakN--;
    if (f.weakF > 0) f.weakF--;
    if (f.guardIntro > 0) f.guardIntro--;
  }

  // knockdown handling
  for (const f of s.f) {
    if (f.down > 0) {
      f.down--;
      const lieFrom = f.cur;
      const lying: Pose = {
        ...clonePose(f.from),
        x: f.from.x,
        lift: -46,
        crouch: 0.85,
        lean: -1.25 * f.facing * 0 + -1.25,
        handN: { x: 18, y: 60 },
        handF: { x: -14, y: 52 },
        footN: { x: 34, y: 6 },
        footF: { x: 44, y: 2 },
      };
      lying.lean = -1.25;
      f.cur = lying;
      f.p = 1;
      void lieFrom;
      if (f.down === 0) {
        f.recovering = 1;
        f.from = clonePose(f.cur);
        f.target = neutralPose(f.cur.x, 0.26);
        f.target.lift = 0;
        f.p = 0;
        f.dur = 34;
        f.bal = Math.max(f.bal, 34);
      }
      done[f.id] = true;
      continue;
    }
    if (f.recovering > 0) f.recovering--;
  }

  const active = s.f.filter((f) => f.down === 0);
  void active;

  // progress + pose integration
  for (const f of s.f) {
    if (f.down > 0) continue;
    const lowSta = f.sta < 22 ? 1.5 : 1;
    const speedMul = lowSta * (f.stagger > 12 ? 1.7 : 1) * (s.active.p.has("explosive") && f.id === 0 ? 0.62 : 1);
    const dur = Math.max(14, f.dur * speedMul);
    if (f.p < 1) f.p = clamp(f.p + 1 / dur, 0, 1);
    else done[f.id] = true;

    const prevX = f.cur.x;
    const base = interpolatePose(f.from, f.target, f.p, f.recovering === 0);

    // root motion: spring toward the planned position + knockback impulse
    const rate = f.stagger > 10 ? 0.055 : 0.16 * (s.active.p.has("explosive") && f.id === 0 ? 2.1 : 1);
    let nx = f.cur.x + (base.x - f.cur.x) * rate;
    f.vel *= 0.86;
    if (Math.abs(f.vel) < 0.02) f.vel = 0;
    nx += f.vel;

    // platform bounds
    nx = clamp(nx, STAGE.left, STAGE.right);
    // fighters can't occupy the same space
    const other = s.f[1 - f.id];
    const gap = nx - other.cur.x;
    if (Math.abs(gap) < 42) nx = other.cur.x + Math.sign(gap || f.facing) * 42;
    nx = clamp(nx, STAGE.left, STAGE.right);

    if (f.stagger > 14 && f.p >= 1) {
      // staggered: the body wobbles instead of holding the pose
      base.lean = f.cur.lean + Math.sin(s.tick * 0.4 + f.id) * 0.16;
      base.handN = { x: base.handN.x - 6, y: base.handN.y - 10 + Math.sin(s.tick * 0.5) * 8 };
      base.handF = { x: base.handF.x - 6, y: base.handF.y - 10 - Math.sin(s.tick * 0.5) * 8 };
      base.weight = 0;
    }
    base.x = nx;
    f.cur = base;

    // rotational impulse from impacts survives pose recomputation
    if (f.spin) {
      f.cur.lean = clamp(f.cur.lean + f.spin, -1.35, 1.35);
      f.spin *= 0.9;
      if (Math.abs(f.spin) < 0.003) f.spin = 0;
    }

    if (f.p >= 1) done[f.id] = true;

    // stamina / guard / balance regeneration
    f.sta = clamp(f.sta + (f.tag === "hold" ? 0.3 : 0.19), 0, 100);
    f.grd = clamp(f.grd + (f.grd < 100 ? 0.13 : 0), 0, 100);
    const target = stanceFactor(f);
    f.bal = clamp(f.bal + (target - f.bal) * (f.stagger > 8 ? 0.004 : 0.021), 0, 100);

    updateStrands(f, prevX);
  }

  // ── contacts ─────────────────────────────────────────────────────────────
  const hits = s.hitSet;
  if (!opts.sandbox) {
    for (const A2 of s.f) {
      const D2 = s.f[1 - A2.id];
      if (A2.down > 0 || D2.down > 0) continue;
      const rw = worldRig(A2.cur, A2.facing);
      const prw = worldRig(A2.from, A2.facing);
      void prw;
      const limbs: { which: "N" | "F"; p: Pt; prev: Pt; kind: "fist" | "palm" | "foot" }[] = [
        { which: "N", p: rw.hdN, prev: A2.prevN, kind: A2.cur.kindN },
        { which: "F", p: rw.hdF, prev: A2.prevF, kind: A2.cur.kindF },
        { which: "N", p: rw.ftN, prev: A2.prevFootN, kind: "foot" },
        { which: "F", p: rw.ftF, prev: A2.prevFootF, kind: "foot" },
      ];
      for (const L of limbs) {
        const isFoot = L.kind === "foot";
        // only limbs actually moving register — a held guard is not an attack
        const vx = L.p.x - L.prev.x;
        const vy = L.p.y - L.prev.y;
        const speed = Math.hypot(vx, vy);
        const intent = isFoot ? speed > 1.5 : speed > 1.1;
        if (!intent) continue;
        const contact = contactPointOK(s, A2, D2, L.p, isFoot);
        if (!contact) continue;
        const c: Contact = {
          attacker: A2,
          defender: D2,
          point: contact.point,
          zone: contact.zone,
          kind: L.kind,
          vel: speed,
          dir: A2.facing,
          isHand: !isFoot,
          isFoot,
          which: L.which,
          power: contactPower(s, A2, speed, isFoot, L.kind),
          precise: clamp(1 - contact.d / 16, 0, 1),
        };
        resolveContact(s, c, hits);
      }
      // fist-on-fist clash
    }
    for (const A2 of s.f) {
      const D2 = s.f[1 - A2.id];
      if (A2.down > 0 || D2.down > 0) continue;
      const ra = worldRig(A2.cur, A2.facing);
      const rb = worldRig(D2.cur, D2.facing);
      const pairs: [Pt, Pt, Pt, Pt][] = [
        [ra.hdN, A2.prevN, rb.hdN, D2.prevN],
        [ra.hdN, A2.prevN, rb.hdF, D2.prevF],
        [ra.hdF, A2.prevF, rb.hdN, D2.prevN],
        [ra.hdF, A2.prevF, rb.hdF, D2.prevF],
      ];
      for (const [pa, va, pb, vb] of pairs) {
        const d = Math.hypot(pa.x - pb.x, pa.y - pb.y);
        if (d > 24) continue;
        const sa = Math.hypot(pa.x - va.x, pa.y - va.y);
        const sb = Math.hypot(pb.x - vb.x, pb.y - vb.y);
        if (sa < 1.4 || sb < 1.4) continue;
        if (hits.has("clash")) continue;
        hits.add("clash");
        const pw = (sa + sb) * 1.35;
        pushBy(A2, -A2.facing * pw * 1.2);
        pushBy(D2, -D2.facing * pw * 1.2);
        A2.stagger = Math.max(A2.stagger, 9);
        D2.stagger = Math.max(D2.stagger, 9);
        A2.bal = clamp(A2.bal - pw * 0.6, 0, 100);
        D2.bal = clamp(D2.bal - pw * 0.6, 0, 100);
        A2.sta = clamp(A2.sta - pw * 0.6, 0, 100);
        D2.sta = clamp(D2.sta - pw * 0.6, 0, 100);
        A2.grd = clamp(A2.grd - 6, 0, 100);
        D2.grd = clamp(D2.grd - 6, 0, 100);
        push(s, { kind: "clash", side: 1, zone: "arm", power: pw, x: (pa.x + pb.x) / 2, y: (pa.y + pb.y) / 2, text: "CLASH", heavy: pw > 16 });
        s.shake = Math.max(s.shake, 5);
        s.hitStop = Math.max(s.hitStop, 5);
      }
    }
  }

  // remember this frame's limb positions for next tick's velocity test
  for (const f of s.f) {
    const rw = worldRig(f.cur, f.facing);
    f.prevN = rw.hdN;
    f.prevF = rw.hdF;
    f.prevFootN = rw.ftN;
    f.prevFootF = rw.ftF;
  }

  // ── end of turn ──
  const settled = s.tick > s.turnStart + 14;
  const allDone = settled && s.f.every((f) => f.p >= 1 || f.down > 0);
  if (allDone) {
    for (const f of s.f) {
      f.from = clonePose(f.cur);
      f.target = clonePose(f.cur);
      f.target.x = f.cur.x;
      f.p = 1;
      f.vel *= 0.4;
    }
    s.ended = true;
  }

  record(s);
  s.tick++;

  // victory
  const [p, o] = s.f;
  if (!opts.training && !opts.sandbox) {
    if (p.hp <= 0) {
      s.ended = true;
      s.winner = 1;
    } else if (o.hp <= 0) {
      s.ended = true;
      s.winner = 0;
    }
    if (p.bal <= 0.5 && p.hp <= 6) {
      s.winner = 1;
      s.ended = true;
    }
    if (s.winner === null && s.turn > 60) {
      s.winner = p.hp === o.hp ? null : p.hp > o.hp ? 0 : 1;
      s.ended = true;
    }
    void o;
  }
}

function record(s: Sim) {
  s.log.push({
    a: clonePose(s.f[0].cur),
    b: clonePose(s.f[1].cur),
    evs: s.events.slice(),
    shake: s.shake,
    hp: [s.f[0].hp, s.f[1].hp],
    bal: [s.f[0].bal, s.f[1].bal],
  });
  if (s.log.length > 12000) s.log.shift();
}

// ── turn setup ─────────────────────────────────────────────────────────────
export function tagOf(from: Pose, to: Pose): MoveTag {
  const dx = to.x - from.x;
  void dx;
  const reachN = to.handN.x;
  const reachF = to.handF.x;
  const footAdvance = to.footN.x - from.footN.x;
  const footHigh = Math.max(to.footN.y, to.footF.y);
  const guardHigh = to.handN.y > 132 && to.handF.y > 132 && Math.abs(to.handN.x - from.handN.x) < 22;
  if (footHigh > 60 && Math.abs(to.footF.x) > 50) return "highKick";
  if (footHigh > 26 && Math.max(reachN, reachF) < 46) return "lowKick";
  if (to.footN.x > 56 && to.kindN === "palm") return "sweep";
  if (guardHigh) return "guardHigh";
  if (to.kindN === "palm" && to.kindF === "palm" && reachN > 40 && reachF > 40) return "grab";
  if (to.kindF === "palm" && reachF > 52) return "palmPush";
  if (reachF > 58 && reachF > reachN + 6) return "cross";
  if (reachN > 56) return "jab";
  if (Math.abs(to.lean - from.lean) < 0.12 && to.kindN === "palm") return "parry";
  if (footAdvance < -34) return "slipBack";
  if (footAdvance > 34) return "stepIn";
  if (reachF > 40 || reachN > 40) return "body";
  return "hold";
}

export function beginTurn(s: Sim, planA: Plan, planB: Plan) {
  const [A, B] = s.f;
  A.from = clonePose(A.cur);
  A.target = clonePose(planA.pose);
  A.p = 0;
  A.tag = planA.tag;
  const readyness = s.active.p.has("readiness");
  A.dur = Math.round(46 / planA.tempo) - (readyness ? 3 : 0);
  A.sta = clamp(A.sta - (5 + planA.tempo * 4 + commitAmount(A.from, A.target) * 3.5), 0, 100);

  B.from = clonePose(B.cur);
  B.target = clonePose(planB.pose);
  B.p = 0;
  B.tag = planB.tag;
  B.dur = Math.round(46 / planB.tempo);
  B.sta = clamp(B.sta - (5 + planB.tempo * 4 + commitAmount(B.from, B.target) * 3.5), 0, 100);

  if (s.active.p.has("flowing")) {
    A.cur.lean += A.facing * s.carry * 0.1;
    s.carry = 0;
  }

  s.habits.push(planA.tag);
  if (s.habits.length > 14) s.habits.shift();
  s.aiHabits.push(planB.tag);
  if (s.aiHabits.length > 14) s.aiHabits.shift();

  s.turn++;
  s.turnStart = s.tick;
  s.ended = false;
  s.hitSet.clear();
  s.secondThoughtUsed = false;
  s.pausedForThought = false;
}

export function resetFighterTo(s: Sim, who: 0 | 1, pose: Pose) {
  const f = s.f[who];
  f.from = clonePose(pose);
  f.target = clonePose(pose);
  f.cur = clonePose(pose);
  f.p = 1;
}

// ── preview ────────────────────────────────────────────────────────────────
export interface PreviewResult {
  samples: { p: number; pose: Pose }[];
  contacts: { x: number; y: number; zone: ZoneId; limb: string; t: number; kind: string }[];
  maxSpeed: number;
  reach: number;
  vulnerable: { head: boolean; torso: boolean };
  countered: boolean;
  pushForward: number;
}

export function preview(s: Sim, planA: Plan, opts: { reveal: boolean; emptyMind: boolean }): PreviewResult {
  const [A, B] = s.f;
  const samples: PreviewResult["samples"] = [];
  const contacts: PreviewResult["contacts"] = [];
  const dur = Math.max(16, Math.round(46 / planA.tempo));
  const from = clonePose(A.cur);
  const to = clonePose(planA.pose);
  // the opponent holds their current stance — their *plan* stays hidden
  const prev: Record<string, { x: number; y: number } | null> = { handN: null, handF: null, footN: null, footF: null };
  let maxSpeed = 0;
  let reach = 0;
  let fwd = 0;
  const seenContact = new Set<string>();
  const ow = worldRig(B.cur, B.facing);
  const zdefs: [string, Pt, Pt, number][] = [
    ["head", ow.head, ow.head, 16],
    ["torso", ow.neck, ow.pelvis, 15],
    ["arm", ow.shF, ow.hdF, 12],
    ["leg", ow.hipN, ow.ftN, 13],
    ["leg", ow.knN, ow.ftN, 12],
  ];

  for (let i = 0; i <= dur; i++) {
    const p = i / dur;
    const pose = interpolatePose(from, to, p, true);
    pose.x = from.x + (to.x - from.x) * (1 - Math.pow(1 - p, 3));
    samples.push({ p, pose });
    const rw = worldRig(pose, A.facing);
    for (const [name, pt, kind] of [
      ["handN", rw.hdN, pose.kindN],
      ["handF", rw.hdF, pose.kindF],
      ["footN", rw.ftN, "foot"],
      ["footF", rw.ftF, "foot"],
    ] as [string, Pt, string][]) {
      const pv = prev[name];
      if (pv && name.startsWith("hand")) {
        const sp = Math.hypot(pt.x - pv.x, pt.y - pv.y);
        if (sp > maxSpeed) maxSpeed = sp;
      }
      prev[name] = { x: pt.x, y: pt.y };
      reach = Math.max(reach, (pt.x - pose.x) * A.facing);
      // does it intersect the opponent's *current* body?
      const zones = zdefs;
      for (const [zn, a2, b2, rr] of zones) {
        const dx = b2.x - a2.x;
        const dy = b2.y - a2.y;
        const l2 = dx * dx + dy * dy || 1e-6;
        let t = ((pt.x - a2.x) * dx + (pt.y - a2.y) * dy) / l2;
        t = clamp(t, 0, 1);
        const d = Math.hypot(pt.x - (a2.x + dx * t), pt.y - (a2.y + dy * t));
        if (d < rr + 11 && !seenContact.has(name + zn)) {
          seenContact.add(name + zn);
          contacts.push({
            x: a2.x + dx * t,
            y: a2.y + dy * t,
            zone: zn as ZoneId,
            limb: name,
            t: p,
            kind,
          });
        }
      }
    }
    fwd = pose.x - from.x;
  }

  // exposure: is anything left uncovered at the end of the extension?
  const last = samples[samples.length - 1];
  const endRw = worldRig(last.pose, A.facing);
  const headPt = endRw.head;
  const pel = endRw.pelvis;
  const near = (a: Pt, b: Pt, r: number) => Math.hypot(a.x - b.x, a.y - b.y) < r;
  const coverHead =
    near(endRw.hdN, headPt, last.pose.kindN === "palm" ? 36 : 31) ||
    near(endRw.hdF, headPt, last.pose.kindF === "palm" ? 36 : 31);
  const coverBody = near(endRw.hdN, pel, 42) || near(endRw.hdF, pel, 42);
  const vulnerable = { head: !coverHead, torso: !coverBody };

  // counter read — from the opponent's *visible current stance* only
  const oppRig = worldRig(B.cur, B.facing);
  const radius = opts.emptyMind ? 74 : 44;
  let countered = false;
  const strikes = [
    { p: endRw.hdN, k: last.pose.kindN, ext: (endRw.hdN.x - pel.x) * A.facing },
    { p: endRw.hdF, k: last.pose.kindF, ext: (endRw.hdF.x - pel.x) * A.facing },
  ];
  for (const st of strikes) {
    if (st.ext < 40) continue;
    const dN = Math.hypot(oppRig.hdN.x - st.p.x, oppRig.hdN.y - st.p.y);
    const dF = Math.hypot(oppRig.hdF.x - st.p.x, oppRig.hdF.y - st.p.y);
    const d = Math.min(dN, dF);
    const kind = dN <= dF ? B.cur.kindN : B.cur.kindF;
    if (d < radius && kind === "palm") countered = true;
  }
  if (opts.emptyMind && !countered) {
    // their guard is otherwise primed across the centreline
    countered = B.cur.kindN === "palm" && B.cur.kindF === "palm" && Math.abs(oppRig.hdN.x - headPt.x) < 60;
  }

  return { samples, contacts, maxSpeed, reach, vulnerable, countered, pushForward: fwd };
}

export function rand(seed: number) {
  return mulberry(seed);
}
export { TAU, lerp };
