// Arts, opponents, and mode definitions — the game's actual written content.

export interface Art {
  id: string;
  cn: string;
  en: string;
  desc: string;
  charges: number; // uses per fight
}

export const ARTS: Art[] = [
  { id: "ghost", cn: "讀影", en: "GHOST READING", desc: "Reveal the opponent's planned ghost for one turn. You see exactly what they intend before you commit.", charges: 3 },
  { id: "empty", cn: "空心", en: "EMPTY MIND", desc: "Preview shows the reaction their current stance is most likely to produce — read the guard, not the plan.", charges: 4 },
  { id: "afterimage", cn: "殘影", en: "AFTERIMAGE", desc: "Leave a false ghost of your intended pose. Predicting opponents will aim where you were going to be.", charges: 2 },
  { id: "iron", cn: "鐵掌", en: "IRON PALM", desc: "Palm guards absorb far more impact. Blocked strikes barely dent your guard and cost them more.", charges: 5 },
  { id: "counter", cn: "順勢", en: "COUNTERFLOW", desc: "When a fist lands on a correctly positioned palm, half of its momentum is redirected straight back into them.", charges: 4 },
  { id: "explosive", cn: "爆步", en: "EXPLOSIVE STEP", desc: "One turn of dramatically faster forward movement. Close the distance before the guard settles.", charges: 3 },
  { id: "shadow", cn: "影步", en: "SHADOW STEP", desc: "Reposition much farther during planning without spending stamina on the step.", charges: 4 },
  { id: "rooted", cn: "沉橋", en: "ROOTED STANCE", desc: "Knockback against you is reduced to a third for one turn. You stay exactly where you planted.", charges: 4 },
  { id: "second", cn: "回念", en: "SECOND THOUGHT", desc: "When both moves are already in motion, time stops once and lets you nudge your line before impact.", charges: 2 },
  { id: "pressure", cn: "點穴", en: "PRESSURE POINT", desc: "Strikes landing dead-centre on a joint weaken that limb for two turns — they lose reach and power.", charges: 3 },
  { id: "flowing", cn: "流水", en: "FLOWING WATER", desc: "Your pose carries 30% more momentum into the next turn. Chains hit harder than single strikes.", charges: 4 },
  { id: "readiness", cn: "先機", en: "FIRST WORD", desc: "Your action begins two ticks earlier this turn. Whoever moves first decides the exchange.", charges: 3 },
];

export const ART_BY_ID: Record<string, Art> = Object.fromEntries(ARTS.map((a) => [a.id, a]));

export interface Personality {
  advance: number; // want to close distance
  aggression: number; // 0..1
  palmUse: number;
  kickUse: number;
  headMovement: number;
  range: number; // preferred standoff distance
  predict: number; // habit tracking strength
  combo: number; // likelihood of chaining attacks
}

export interface Opponent {
  id: string;
  cn: string;
  en: string;
  title: string;
  bio: string;
  accent: string;
  ink: string;
  diff: number; // 0..4
  stats: { dmg: number; def: number; spd: number; bal: number };
  p: Personality;
  roster: string[]; // moves they favour
}

export const OPPONENTS: Opponent[] = [
  {
    id: "basher",
    cn: "嚴",
    en: "YAN THE BASHER",
    title: "The Sanded Board",
    bio: "Walks forward and does not stop. Leads with the rear hand, eats palm strikes to give back hooks. His guard is a suggestion.",
    accent: "#C1272D",
    ink: "#1B1815",
    diff: 0,
    stats: { dmg: 7, def: 3, spd: 5, bal: 6 },
    p: { advance: 0.9, aggression: 0.92, palmUse: 0.12, kickUse: 0.3, headMovement: 0.15, range: 78, predict: 0.1, combo: 0.7 },
    roster: ["cross", "body", "stepIn", "guardHigh"],
  },
  {
    id: "qiao",
    cn: "喬",
    en: "SISTER QIAO",
    title: "The Waiting Palm",
    bio: "Refuses to swing first. Holds a double palm guard, lets the fist arrive, then turns it. Punish her patience too early and you will find nothing there.",
    accent: "#2E4A6B",
    ink: "#1B1815",
    diff: 1,
    stats: { dmg: 5, def: 9, spd: 6, bal: 7 },
    p: { advance: 0.2, aggression: 0.24, palmUse: 0.86, kickUse: 0.2, headMovement: 0.55, range: 118, predict: 0.35, combo: 0.55 },
    roster: ["parry", "guardHigh", "palmPush", "slipBack", "cross"],
  },
  {
    id: "ma",
    cn: "馬",
    en: "MA BOXER",
    title: "Sixty Rounds",
    bio: "Hands high, chin tucked, feet squared. Devastating at boxing range and completely uninterested in your legs — until he is losing.",
    accent: "#8A161C",
    ink: "#1B1815",
    diff: 2,
    stats: { dmg: 8, def: 7, spd: 8, bal: 6 },
    p: { advance: 0.62, aggression: 0.7, palmUse: 0.2, kickUse: 0.04, headMovement: 0.8, range: 92, predict: 0.4, combo: 0.78 },
    roster: ["jab", "cross", "body", "slipBack", "stepIn"],
  },
  {
    id: "chen",
    cn: "陳",
    en: "OLD CHEN",
    title: "Thirty Years of Circle Step",
    bio: "Fights off angles. Redirection over collision — he wants your arm extended so he can walk around it and take your balance from the side.",
    accent: "#6B6151",
    ink: "#1B1815",
    diff: 2,
    stats: { dmg: 6, def: 8, spd: 7, bal: 9 },
    p: { advance: 0.5, aggression: 0.5, palmUse: 0.62, kickUse: 0.55, headMovement: 0.5, range: 104, predict: 0.5, combo: 0.72 },
    roster: ["parry", "palmPush", "lowKick", "sweep", "body", "stepIn"],
  },
  {
    id: "wu",
    cn: "吳",
    en: "GRAPPLER WU",
    title: "The Kettle",
    bio: "Wants to be inside your reach. Once he is close he stops punching and starts unbalancing — every exchange is a fight for your footing.",
    accent: "#3A342C",
    ink: "#1B1815",
    diff: 3,
    stats: { dmg: 6, def: 6, spd: 5, bal: 10 },
    p: { advance: 0.95, aggression: 0.6, palmUse: 0.5, kickUse: 0.35, headMovement: 0.3, range: 54, predict: 0.5, combo: 0.6 },
    roster: ["grab", "palmPush", "sweep", "body", "stepIn"],
  },
  {
    id: "zheng",
    cn: "鄭",
    en: "MASTER ZHENG",
    title: "Reads the Habit",
    bio: "Watches what you do when you are afraid. Repeat yourself twice and he will already be standing where your fist was going to be.",
    accent: "#C1272D",
    ink: "#1B1815",
    diff: 4,
    stats: { dmg: 9, def: 9, spd: 9, bal: 9 },
    p: { advance: 0.55, aggression: 0.58, palmUse: 0.6, kickUse: 0.5, headMovement: 0.7, range: 100, predict: 0.95, combo: 0.85 },
    roster: ["parry", "cross", "lowKick", "slipBack", "palmPush", "body", "jab", "sweep"],
  },
];

export const OPP_BY_ID: Record<string, Opponent> = Object.fromEntries(OPPONENTS.map((o) => [o.id, o]));

export type ModeId = "training" | "duel" | "challenge" | "master" | "sandbox" | "replay";

export interface ModeDef {
  id: ModeId;
  cn: string;
  en: string;
  blurb: string;
  turns?: number;
}

export const MODES: ModeDef[] = [
  { id: "training", cn: "練", en: "TRAINING", blurb: "A compliant partner, unlimited previews, and every hitbox and trajectory drawn on the paper." },
  { id: "duel", cn: "鬥", en: "DUEL", blurb: "One opponent, one fight. Standard rules, hidden intent, a cinematic replay at the end." },
  { id: "challenge", cn: "試", en: "CHALLENGE", blurb: "Five opponents in sequence. What you unlock carries forward; your habits are remembered." },
  { id: "master", cn: "宗", en: "MASTER", blurb: "Master Zheng, at full strength, tracking every repeat you make." },
  { id: "sandbox", cn: "戲", en: "SANDBOX", blurb: "No damage, no timer, no opponent intent. A studio for posing bodies and watching physics." },
  { id: "replay", cn: "錄", en: "REPLAY", blurb: "The library. Re-watch anything you have finished, frame by frame, from any camera." },
];

export const ZONES = {
  head: { dmg: 1.7, bal: 1.35, sta: 0.7, guard: 1.0, kb: 1.0, label: "HEAD" },
  torso: { dmg: 1.0, bal: 0.8, sta: 1.6, guard: 1.0, kb: 1.1, label: "TORSO" },
  arm: { dmg: 0.55, bal: 0.5, sta: 0.5, guard: 1.5, kb: 0.7, label: "ARM" },
  leg: { dmg: 0.45, bal: 2.0, sta: 0.9, guard: 0.5, kb: 0.8, label: "LEG" },
} as const;

export type ZoneId = keyof typeof ZONES;
