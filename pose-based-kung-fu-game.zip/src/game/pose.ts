// ── Skeleton definition, forward kinematics, 2-bone IK, pose interpolation ──
// Local space: origin on the ground directly under the fighter, +x = the
// direction the fighter faces, y = height above the floor.

export type HandKind = "fist" | "palm";
export type Focus = "root" | "torso" | "handN" | "handF" | "footN" | "footF";

export interface Pt {
  x: number;
  y: number;
}

export interface Pose {
  x: number; // world x of the root
  lift: number; // vertical offset of the whole body (knockdowns / jumps)
  crouch: number; // 0..1
  lean: number; // radians, + tips the torso forward
  twist: number; // -1..1 torso rotation (near shoulder forward / back)
  weight: number; // -1 rear .. +1 front
  handN: Pt; // near / lead hand target (local)
  handF: Pt; // far / rear hand target (local)
  footN: Pt;
  footF: Pt;
  kindN: HandKind;
  kindF: HandKind;
}

export const DIM = {
  torso: 52,
  neck: 13,
  headR: 15,
  upper: 30,
  fore: 29,
  thigh: 40,
  shin: 38,
  pelvis: 78,
};

export const clamp = (v: number, a: number, b: number) => (v < a ? a : v > b ? b : v);
export const lerp = (a: number, b: number, t: number) => a + (b - a) * t;
export const TAU = Math.PI * 2;

export function normAngle(a: number) {
  while (a > Math.PI) a -= TAU;
  while (a < -Math.PI) a += TAU;
  return a;
}

// ── forward kinematics (local space) ───────────────────────────────────────
export function pelvisOf(p: Pose): Pt {
  return { x: 0, y: DIM.pelvis - p.crouch * 24 };
}
export function neckOf(p: Pose): Pt {
  const pv = pelvisOf(p);
  return { x: pv.x + Math.sin(p.lean) * DIM.torso, y: pv.y + Math.cos(p.lean) * DIM.torso };
}
export function headOf(p: Pose): Pt {
  const n = neckOf(p);
  const a = p.lean * 0.55 - 0.06;
  return { x: n.x + Math.sin(a) * (DIM.neck + DIM.headR * 0.55), y: n.y + Math.cos(a) * (DIM.neck + DIM.headR * 0.55) };
}
export function shoulderNear(p: Pose): Pt {
  const n = neckOf(p);
  return { x: n.x + 4 + p.twist * 3, y: n.y - 2 };
}
export function shoulderFar(p: Pose): Pt {
  const n = neckOf(p);
  return { x: n.x - 5 - p.twist * 4, y: n.y - 5 };
}
export function hipNear(p: Pose): Pt {
  const pv = pelvisOf(p);
  return { x: pv.x + 4, y: pv.y - 1 };
}
export function hipFar(p: Pose): Pt {
  const pv = pelvisOf(p);
  return { x: pv.x - 5, y: pv.y - 3 };
}

// ── 2-bone IK ──────────────────────────────────────────────────────────────
function ik(root: Pt, target: Pt, l1: number, l2: number, sign: number): Pt {
  let dx = target.x - root.x;
  let dy = target.y - root.y;
  let d = Math.hypot(dx, dy);
  const max = (l1 + l2) * 0.998;
  if (d > max) {
    dx *= max / d;
    dy *= max / d;
    d = max;
  }
  if (d < 0.001) {
    dx = 0;
    dy = -0.001;
    d = 0.001;
  }
  const a = (l1 * l1 - l2 * l2 + d * d) / (2 * d);
  const h = Math.sqrt(Math.max(0, l1 * l1 - a * a));
  const ux = dx / d;
  const uy = dy / d;
  const px = -uy * h * sign;
  const py = ux * h * sign;
  return { x: root.x + ux * a + px, y: root.y + uy * a + py };
}

export interface Rig {
  pelvis: Pt;
  neck: Pt;
  head: Pt;
  shN: Pt;
  shF: Pt;
  elN: Pt;
  elF: Pt;
  hdN: Pt;
  hdF: Pt;
  hipN: Pt;
  hipF: Pt;
  knN: Pt;
  knF: Pt;
  ftN: Pt;
  ftF: Pt;
}

export function rig(p: Pose): Rig {
  const pelvis = pelvisOf(p);
  const neck = neckOf(p);
  const head = headOf(p);
  const shN = shoulderNear(p);
  const shF = shoulderFar(p);
  const hipN = hipNear(p);
  const hipF = hipFar(p);
  // arm targets are clamped into reach so a bad drag can't break the skeleton
  const clampReach = (s: Pt, t: Pt) => {
    const dx = t.x - s.x;
    const dy = t.y - s.y;
    const d = Math.hypot(dx, dy);
    const max = DIM.upper + DIM.fore;
    if (d <= max) return t;
    return { x: s.x + (dx / d) * max, y: s.y + (dy / d) * max };
  };
  const tN = clampReach(shN, p.handN);
  const tF = clampReach(shF, p.handF);
  const hdN = tN;
  const hdF = tF;
  const elN = ik(shN, tN, DIM.upper, DIM.fore, -1);
  const elF = ik(shF, tF, DIM.upper, DIM.fore, -1);
  const knN = ik(hipN, p.footN, DIM.thigh, DIM.shin, 1);
  const knF = ik(hipF, p.footF, DIM.thigh, DIM.shin, 1);
  return { pelvis, neck, head, shN, shF, elN, elF, hdN, hdF, hipN, hipF, knN, knF, ftN: p.footN, ftF: p.footF };
}

export function toWorld(p: Pose, facing: number, l: Pt): Pt {
  return { x: p.x + facing * l.x, y: l.y + p.lift };
}

export function worldRig(p: Pose, facing: number) {
  const r = rig(p);
  const w = <K extends keyof Rig>(k: K) => toWorld(p, facing, r[k]);
  return {
    pelvis: w("pelvis"),
    neck: w("neck"),
    head: w("head"),
    shN: w("shN"),
    shF: w("shF"),
    elN: w("elN"),
    elF: w("elF"),
    hdN: w("hdN"),
    hdF: w("hdF"),
    hipN: w("hipN"),
    hipF: w("hipF"),
    knN: w("knN"),
    knF: w("knF"),
    ftN: w("ftN"),
    ftF: w("ftF"),
  };
}
export type WRig = ReturnType<typeof worldRig>;

// ── pose helpers ───────────────────────────────────────────────────────────
export function clonePose(p: Pose): Pose {
  return {
    x: p.x,
    lift: p.lift,
    crouch: p.crouch,
    lean: p.lean,
    twist: p.twist,
    weight: p.weight,
    handN: { ...p.handN },
    handF: { ...p.handF },
    footN: { ...p.footN },
    footF: { ...p.footF },
    kindN: p.kindN,
    kindF: p.kindF,
  };
}

/** Neutral on-guard stance, facing +x in local space. */
export function neutralPose(x: number, crouch = 0.25): Pose {
  return {
    x,
    lift: 0,
    crouch,
    lean: 0.1,
    twist: 0.15,
    weight: -0.1,
    handN: { x: 30, y: 118 },
    handF: { x: 14, y: 126 },
    footN: { x: 22, y: 0 },
    footF: { x: -22, y: 0 },
    kindN: "fist",
    kindF: "fist",
  };
}

const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);
const ANT = 0.16;

/**
 * Interpolate from a → b. Anticipation is injected into the hand targets and
 * lean so every strike winds up before it fires — the pose a fighter ends a
 * turn in becomes the wind-up for the next one.
 */
export function interpolatePose(a: Pose, b: Pose, p: number, anticipate = true): Pose {
  const wind = anticipate ? -0.14 * Math.sin(clamp(p / ANT, 0, 1) * Math.PI) : 0;
  const t = p < ANT ? wind : easeOut((p - ANT) / (1 - ANT));
  return {
    x: lerp(a.x, b.x, easeOut(p)),
    lift: lerp(a.lift, b.lift, t),
    crouch: lerp(a.crouch, b.crouch, t),
    lean: lerp(a.lean, b.lean, t),
    twist: lerp(a.twist, b.twist, t),
    weight: lerp(a.weight, b.weight, t),
    handN: { x: lerp(a.handN.x, b.handN.x, t), y: lerp(a.handN.y, b.handN.y, t) },
    handF: { x: lerp(a.handF.x, b.handF.x, t), y: lerp(a.handF.y, b.handF.y, t) },
    footN: { x: lerp(a.footN.x, b.footN.x, easeOut(p)), y: lerp(a.footN.y, b.footN.y, easeOut(p)) },
    footF: { x: lerp(a.footF.x, b.footF.x, easeOut(p)), y: lerp(a.footF.y, b.footF.y, easeOut(p)) },
    kindN: p > ANT ? b.kindN : a.kindN,
    kindF: p > ANT ? b.kindF : a.kindF,
  };
}

/** Distance from point to a capsule segment; returns distance and closest pt. */
export function segDist(pt: Pt, a: Pt, b: Pt) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const l2 = dx * dx + dy * dy || 1e-6;
  let t = ((pt.x - a.x) * dx + (pt.y - a.y) * dy) / l2;
  t = clamp(t, 0, 1);
  const cx = a.x + dx * t;
  const cy = a.y + dy * t;
  return { d: Math.hypot(pt.x - cx, pt.y - cy), cx, cy };
}

export function stanceWidth(p: Pose) {
  return Math.abs(p.footN.x - p.footF.x);
}

/** How stable this pose is on its own (0..100). */
export function stanceBase(p: Pose) {
  const w = stanceWidth(p);
  const spreadY = Math.abs(p.footN.y - p.footF.y);
  return clamp(48 + w * 0.62 + (1 - p.crouch) * 12 - spreadY * 0.35, 24, 97);
}

/** How far the fighter is committing their mass this turn (0..1). */
export function commitAmount(from: Pose, to: Pose) {
  const dx = Math.abs(to.x - from.x);
  const dw = Math.abs(to.weight - from.weight);
  const dl = Math.abs(to.lean - from.lean);
  const dhand = Math.hypot(to.handF.x - from.handF.x, to.handF.y - from.handF.y) + Math.hypot(to.handN.x - from.handN.x, to.handN.y - from.handN.y);
  return clamp(dx / 70 + dw * 0.6 + dl * 0.7 + dhand / 160, 0, 1.6);
}
