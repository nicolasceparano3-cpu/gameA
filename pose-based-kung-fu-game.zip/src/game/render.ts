// ── Canvas rendering: ink-brush bodies, stage, trajectories, impacts ───────
import { clamp, rig, worldRig, type Focus, type Pose, type Pt } from "./pose";
import type { Ev, Fighter, Sim } from "./engine";
import { STAGE } from "./engine";

const INK = "#1B1815";
const INK2 = "#3A342C";
const PAPER = "#E8DFCE";
const PAPER2 = "#D6C9AE";
const PAPER3 = "#BCAB8B";
const CINNABAR = "#C1272D";
const INDIGO = "#2E4A6B";
const TAU = Math.PI * 2;

export interface Cam {
  z: number;
  cx: number;
  gy: number; // world y of the ground line on screen, in css px
  shake: number;
}

export function makeCam(w: number, h: number, a: Pose, b: Pose, zoomBoost = 1): Cam {
  const span = clamp(Math.abs(a.x - b.x) + 340, 560, 1000);
  const z = Math.min(w / span, h / 282) * zoomBoost;
  const cx = (a.x + b.x) / 2;
  return { z, cx, gy: h * 0.84, shake: 0 };
}

export const sx = (x: number, c: Cam) => (x - c.cx) * c.z;
export const sy = (y: number, c: Cam) => c.gy - y * c.z;

let outline: string | null = null;

function bone(ctx: CanvasRenderingContext2D, a: Pt, b: Pt, w1: number, w2: number) {
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const L = Math.hypot(dx, dy) || 1;
  const nx = -dy / L;
  const ny = dx / L;
  ctx.beginPath();
  ctx.moveTo(a.x + nx * w1, a.y + ny * w1);
  ctx.lineTo(b.x + nx * w2, b.y + ny * w2);
  ctx.lineTo(b.x - nx * w2, b.y - ny * w2);
  ctx.lineTo(a.x - nx * w1, a.y - ny * w1);
  ctx.closePath();
  ctx.fill();
  if (outline) {
    ctx.strokeStyle = outline;
    ctx.lineWidth = 1.1;
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.arc(a.x, a.y, w1, 0, TAU);
  ctx.fill();
  if (outline) {
    ctx.strokeStyle = outline;
    ctx.lineWidth = 1.1;
    ctx.stroke();
  }
  ctx.beginPath();
  ctx.arc(b.x, b.y, w2, 0, TAU);
  ctx.fill();
  if (outline) {
    ctx.strokeStyle = outline;
    ctx.lineWidth = 1.1;
    ctx.stroke();
  }
}

export interface Style {
  mode: "solid" | "ghost" | "outline";
  accent: string;
  alpha?: number;
  flash?: number;
  focus?: Focus | null;
  ghostOf?: "player" | "enemy";
  debug?: boolean;
}

/** Draw a fighter in world coordinates through the camera transform. */
export function drawFighter(ctx: CanvasRenderingContext2D, p: Pose, facing: number, c: Cam, st: Style) {
  const r = worldRig(p, facing);
  const P = (q: Pt) => ({ x: sx(q.x, c), y: sy(q.y, c) });
  const z = c.z;

  const alpha = st.alpha ?? 1;
  ctx.save();
  ctx.globalAlpha = alpha;

  const ghost = st.mode === "ghost";
  outline = ghost ? (st.ghostOf === "enemy" ? INDIGO : CINNABAR) : null;

  if (ghost) ctx.setLineDash([4, 3.5]);
  const bodyFill = ghost ? (st.ghostOf === "enemy" ? INDIGO : CINNABAR) : st.flash && st.flash > 0 ? "#E0453F" : INK;
  const farFill = ghost ? bodyFill : INK2;

  ctx.fillStyle = bodyFill;

  // far leg
  const knF = P(r.knF);
  const ftF = P(r.ftF);
  const hipF = P(r.hipF);
  ctx.fillStyle = farFill;
  bone(ctx, hipF, knF, 9 * z, 7 * z);
  bone(ctx, knF, ftF, 7 * z, 4.5 * z);
  // far arm
  const shF = P(r.shF);
  const elF = P(r.elF);
  const hdF = P(r.hdF);
  bone(ctx, shF, elF, 8 * z, 6.4 * z);
  bone(ctx, elF, hdF, 6.4 * z, 5 * z);
  drawHand(ctx, hdF, P(r.elF), p.kindF, z, farFill, ghost);

  // torso
  ctx.fillStyle = bodyFill;
  const pel = P(r.pelvis);
  const nk = P(r.neck);
  bone(ctx, pel, nk, 14 * z, 11.5 * z);
  // sash / robe
  if (!ghost) drawSash(ctx, c, p, facing, st.accent);

  // head
  const hd = P(r.head);
  const leanPix = p.lean * 0.5;
  ctx.save();
  ctx.translate(hd.x, hd.y);
  ctx.rotate(-leanPix * facing);
  ctx.fillStyle = bodyFill;
  ctx.beginPath();
  ctx.ellipse(facing * 1.5 * z, 0, 14 * z, 16 * z, 0, 0, TAU);
  ctx.fill();
  // topknot
  ctx.beginPath();
  ctx.ellipse(-facing * 9 * z, -13 * z, 5.5 * z, 6.5 * z, 0, 0, TAU);
  ctx.fill();
  ctx.restore();

  // near leg
  ctx.fillStyle = bodyFill;
  const knN = P(r.knN);
  const ftN = P(r.ftN);
  const hipN = P(r.hipN);
  bone(ctx, hipN, knN, 10 * z, 7.6 * z);
  bone(ctx, knN, ftN, 7.6 * z, 5 * z);
  // foot wedge
  ctx.save();
  ctx.fillStyle = bodyFill;
  ctx.beginPath();
  const dirF = facing;
  ctx.moveTo(ftN.x, ftN.y + 4 * z);
  ctx.lineTo(ftN.x + dirF * 17 * z, ftN.y + 1.5 * z);
  ctx.lineTo(ftN.x + dirF * 17 * z, ftN.y - 3 * z);
  ctx.lineTo(ftN.x - dirF * 6 * z, ftN.y - 3 * z);
  ctx.closePath();
  ctx.fill();
  ctx.restore();

  // near arm
  const shN = P(r.shN);
  const elN = P(r.elN);
  const hdN = P(r.hdN);
  bone(ctx, shN, elN, 8.6 * z, 6.8 * z);
  bone(ctx, elN, hdN, 6.8 * z, 5.4 * z);
  drawHand(ctx, hdN, P(r.elN), p.kindN, z, bodyFill, ghost);

  ctx.setLineDash([]);
  outline = null;
  ctx.restore();
}

function drawHand(ctx: CanvasRenderingContext2D, h: Pt, el: Pt, kind: "fist" | "palm", z: number, fill: string, ghost: boolean) {
  const a = Math.atan2(h.y - el.y, h.x - el.x);
  ctx.save();
  ctx.translate(h.x, h.y);
  ctx.rotate(a);
  ctx.fillStyle = fill;
  if (kind === "fist") {
    ctx.beginPath();
    ctx.ellipse(0, 0, 8.5 * z, 7.5 * z, 0, 0, TAU);
    ctx.fill();
    if (ghost) {
      ctx.strokeStyle = fill;
      ctx.lineWidth = Math.max(1, 1.4 * z);
      ctx.beginPath();
      ctx.moveTo(-3 * z, -5 * z);
      ctx.lineTo(-3 * z, 5 * z);
      ctx.stroke();
    }
  } else {
    ctx.beginPath();
    ctx.ellipse(2 * z, 0, 9.5 * z, 6 * z, 0, 0, TAU);
    ctx.fill();
    // finger notches
    ctx.strokeStyle = ghost ? PAPER : PAPER;
    ctx.lineWidth = Math.max(0.8, 1.1 * z);
    for (let i = -1; i <= 2; i++) {
      ctx.beginPath();
      ctx.moveTo(4 * z, i * 3 * z);
      ctx.lineTo(10.5 * z, i * 3 * z);
      ctx.stroke();
    }
  }
  ctx.restore();
}

function drawSash(ctx: CanvasRenderingContext2D, c: Cam, p: Pose, facing: number, accent: string) {
  const r = rig(p);
  const pel = { x: p.x + facing * r.pelvis.x, y: r.pelvis.y + p.lift };
  ctx.save();
  ctx.fillStyle = accent;
  ctx.globalAlpha *= 0.95;
  const w0 = 11 * c.z;
  ctx.beginPath();
  const a = { x: sx(pel.x, c), y: sy(pel.y, c) };
  const sway = -facing * (6 + p.weight * 8) * c.z;
  const drop = (34 + p.crouch * 8) * c.z;
  ctx.moveTo(a.x - w0, a.y);
  ctx.lineTo(a.x + w0, a.y);
  ctx.lineTo(a.x + w0 * 0.55 + sway, a.y + drop);
  ctx.lineTo(a.x - w0 * 0.75 + sway * 1.4, a.y + drop * 1.08);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

export function drawStrand(ctx: CanvasRenderingContext2D, pts: Pt[], c: Cam, w: number, color: string, taper = 0.35) {
  if (pts.length < 2) return;
  ctx.save();
  ctx.fillStyle = color;
  ctx.beginPath();
  const up: Pt[] = [];
  const dn: Pt[] = [];
  for (let i = 0; i < pts.length; i++) {
    const a = pts[i];
    const b = pts[Math.min(i + 1, pts.length - 1)];
    const dx = b.x - a.x;
    const dy = b.y - a.y;
    const L = Math.hypot(dx, dy) || 1;
    const ww = (w * (1 - (i / (pts.length - 1)) * taper) * c.z) / 2;
    up.push({ x: sx(a.x, c) - (dy / L) * ww, y: sy(a.y, c) + (dx / L) * ww });
    dn.push({ x: sx(a.x, c) + (dy / L) * ww, y: sy(a.y, c) - (dx / L) * ww });
  }
  ctx.moveTo(up[0].x, up[0].y);
  for (const u of up) ctx.lineTo(u.x, u.y);
  for (let i = dn.length - 1; i >= 0; i--) ctx.lineTo(dn[i].x, dn[i].y);
  ctx.closePath();
  ctx.fill();
  ctx.restore();
}

// ── editing handles ────────────────────────────────────────────────────────
export function handlePoints(p: Pose, facing: number): { f: Focus; p: Pt }[] {
  const r = rig(p);
  const W = (l: Pt) => ({ x: p.x + facing * l.x, y: l.y + p.lift });
  return [
    { f: "root", p: W(r.pelvis) },
    { f: "torso", p: W(r.head) },
    { f: "handN", p: W(r.hdN) },
    { f: "handF", p: W(r.hdF) },
    { f: "footN", p: W(r.ftN) },
    { f: "footF", p: W(r.ftF) },
  ];
}

export function hitTest(p: Pose, facing: number, wx: number, wy: number): Focus | null {
  let best: Focus | null = null;
  let bd = 26;
  for (const h of handlePoints(p, facing)) {
    const d = Math.hypot(h.p.x - wx, h.p.y - wy);
    if (d < bd) {
      bd = d;
      best = h.f;
    }
  }
  return best;
}

export function drawHandles(ctx: CanvasRenderingContext2D, p: Pose, facing: number, c: Cam, focus: Focus | null, accent: string) {
  const z = c.z;
  for (const h of handlePoints(p, facing)) {
    const X = sx(h.p.x, c);
    const Y = sy(h.p.y, c);
    const active = focus === h.f;
    const isHand = h.f === "handN" || h.f === "handF";
    const kind = h.f === "handN" ? p.kindN : p.kindF;
    ctx.save();
    ctx.strokeStyle = active ? CINNABAR : accent;
    ctx.fillStyle = active ? CINNABAR : accent;
    ctx.lineWidth = Math.max(1.2, 1.6);
    ctx.globalAlpha = active ? 1 : 0.75;
    if (isHand) {
      if (kind === "fist") {
        ctx.beginPath();
        ctx.arc(X, Y, (active ? 12 : 10) * Math.min(1.15, z), 0, TAU);
        ctx.stroke();
        ctx.beginPath();
        ctx.arc(X, Y, 3.4, 0, TAU);
        ctx.fill();
      } else {
        const s = (active ? 22 : 18) * Math.min(1.15, z);
        ctx.strokeRect(X - s / 2, Y - s / 2.4, s, s / 1.2);
        ctx.beginPath();
        ctx.moveTo(X - s / 3, Y);
        ctx.lineTo(X + s / 3, Y);
        ctx.stroke();
      }
    } else {
      ctx.beginPath();
      ctx.arc(X, Y, active ? 8 : 6, 0, TAU);
      if (h.f === "root") {
        ctx.fill();
        ctx.strokeStyle = PAPER;
        ctx.beginPath();
        ctx.moveTo(X - 5, Y);
        ctx.lineTo(X + 5, Y);
        ctx.stroke();
      } else {
        ctx.stroke();
      }
    }
    ctx.restore();
  }
}

// ── trajectories & impact previews ─────────────────────────────────────────
export function drawTrajectories(
  ctx: CanvasRenderingContext2D,
  samples: { pose: Pose }[],
  facing: number,
  c: Cam,
  accent: string
) {
  if (samples.length < 2) return;
  const paths: Pt[][] = [[], [], [], []];
  for (const s of samples) {
    const r = worldRig(s.pose, facing);
    paths[0].push(r.hdN);
    paths[1].push(r.hdF);
    paths[2].push(r.ftN);
    paths[3].push(r.ftF);
  }
  ctx.save();
  paths.forEach((pts, i) => {
    ctx.beginPath();
    pts.forEach((q, k) => (k ? ctx.lineTo(sx(q.x, c), sy(q.y, c)) : ctx.moveTo(sx(q.x, c), sy(q.y, c))));
    ctx.strokeStyle = accent;
    ctx.globalAlpha = i < 2 ? 0.75 : 0.4;
    ctx.lineWidth = i < 2 ? 1.8 : 1.2;
    ctx.setLineDash(i < 2 ? [] : [3, 4]);
    ctx.stroke();
    // direction ticks
    for (let k = 6; k < pts.length; k += 9) {
      const a = pts[k - 1];
      const b = pts[k];
      const X = sx(b.x, c);
      const Y = sy(b.y, c);
      const ang = Math.atan2(-(b.y - a.y) * c.z, (b.x - a.x) * c.z);
      ctx.globalAlpha = 0.8;
      ctx.beginPath();
      ctx.moveTo(X, Y);
      ctx.lineTo(X - Math.cos(ang - 0.5) * 6, Y - Math.sin(ang - 0.5) * 6);
      ctx.moveTo(X, Y);
      ctx.lineTo(X - Math.cos(ang + 0.5) * 6, Y - Math.sin(ang + 0.5) * 6);
      ctx.stroke();
    }
  });
  ctx.restore();
}

export function drawContacts(
  ctx: CanvasRenderingContext2D,
  contacts: { x: number; y: number; zone: string; t: number; limb: string }[],
  c: Cam,
  accent: string
) {
  ctx.save();
  for (const k of contacts) {
    const X = sx(k.x, c);
    const Y = sy(k.y, c);
    ctx.strokeStyle = CINNABAR;
    ctx.fillStyle = CINNABAR;
    ctx.lineWidth = 1.6;
    ctx.globalAlpha = 0.95;
    const R = 13;
    ctx.beginPath();
    ctx.arc(X, Y, R, 0, TAU);
    ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(X - R - 6, Y);
    ctx.lineTo(X - R + 2, Y);
    ctx.moveTo(X + R - 2, Y);
    ctx.lineTo(X + R + 6, Y);
    ctx.moveTo(X, Y - R - 6);
    ctx.lineTo(X, Y - R + 2);
    ctx.moveTo(X, Y + R - 2);
    ctx.lineTo(X, Y + R + 6);
    ctx.stroke();
    ctx.font = "700 10px 'Barlow Condensed', sans-serif";
    ctx.textAlign = "center";
    ctx.fillText(k.zone.toUpperCase(), X, Y - R - 9);
  }
  ctx.restore();
  void accent;
}

// ── stage ──────────────────────────────────────────────────────────────────
export function drawStage(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  c: Cam,
  bg: HTMLImageElement | null,
  paper: HTMLImageElement | null
) {
  ctx.save();
  ctx.fillStyle = PAPER;
  ctx.fillRect(0, 0, w, h);

  if (paper && paper.complete && paper.naturalWidth) {
    ctx.globalAlpha = 0.5;
    ctx.globalCompositeOperation = "multiply";
    const t = 420;
    for (let x = 0; x < w; x += t) for (let y = 0; y < h; y += t) ctx.drawImage(paper, x, y, t, t);
    ctx.globalCompositeOperation = "source-over";
    ctx.globalAlpha = 1;
  }

  // backdrop with parallax
  if (bg && bg.complete && bg.naturalWidth) {
    const par = -(c.cx - 600) * 0.1;
    const bw = Math.max(w * 1.25, 1400);
    const bh = (bw / bg.naturalWidth) * bg.naturalHeight;
    ctx.globalAlpha = 0.62;
    ctx.drawImage(bg, par - (bw - w) / 2, c.gy - bh * 0.86, bw, bh);
    ctx.globalAlpha = 1;
  }

  // ground band
  const gy = c.gy;
  const grad = ctx.createLinearGradient(0, gy, 0, h);
  grad.addColorStop(0, PAPER2);
  grad.addColorStop(1, PAPER3);
  ctx.fillStyle = grad;
  ctx.fillRect(0, gy, w, h - gy);

  // brush horizon line
  ctx.strokeStyle = "rgba(27,24,21,0.5)";
  ctx.lineWidth = 2;
  ctx.beginPath();
  for (let x = 0; x <= w; x += 6) {
    const t = x / w;
    const wob = Math.sin(t * 43) * 0.8 + Math.sin(t * 11) * 1.4;
    if (x === 0) ctx.moveTo(x, gy + wob);
    else ctx.lineTo(x, gy + wob);
  }
  ctx.stroke();

  // stage boundary ticks
  ctx.strokeStyle = "rgba(193,39,45,0.35)";
  ctx.setLineDash([6, 8]);
  ctx.lineWidth = 1.4;
  for (const bX of [STAGE.left, STAGE.right]) {
    const X = sx(bX, c);
    ctx.beginPath();
    ctx.moveTo(X, gy);
    ctx.lineTo(X, gy - 190 * c.z);
    ctx.stroke();
  }
  ctx.setLineDash([]);

  // floor boards
  ctx.strokeStyle = "rgba(27,24,21,0.14)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 10; i++) {
    const y = gy + i * i * 4.6 * Math.min(c.z, 2.4);
    if (y > h) break;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(w, y);
    ctx.stroke();
  }
  ctx.restore();
}

// ── particles & impacts ────────────────────────────────────────────────────
export interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  max: number;
  kind: "dust" | "sweat" | "ink" | "seal";
  size: number;
  rot: number;
}

export function spawnImpact(out: Particle[], x: number, y: number, heavy: boolean, side: number) {
  const n = heavy ? 9 : 4;
  for (let i = 0; i < n; i++) {
    const a = Math.random() * TAU;
    const sp = (heavy ? 2.6 : 1.4) * (0.4 + Math.random());
    out.push({ x, y, vx: Math.cos(a) * sp + side * 0.6, vy: Math.sin(a) * sp + 0.6, life: 0, max: 26 + Math.random() * 18, kind: "ink", size: heavy ? 3 + Math.random() * 5 : 2 + Math.random() * 3, rot: Math.random() * TAU });
  }
  for (let i = 0; i < (heavy ? 7 : 3); i++) {
    out.push({ x, y, vx: (Math.random() - 0.5) * 3 + side, vy: Math.random() * 2.4, life: 0, max: 34 + Math.random() * 20, kind: "sweat", size: 1.4 + Math.random() * 1.6, rot: -Math.random() * Math.PI });
  }
}

export function spawnDust(out: Particle[], x: number, y: number, dir: number) {
  for (let i = 0; i < 4; i++) {
    out.push({
      x: x + (Math.random() - 0.5) * 14,
      y,
      vx: -dir * (0.3 + Math.random() * 1.1),
      vy: 0.3 + Math.random() * 0.7,
      life: 0,
      max: 30 + Math.random() * 18,
      kind: "dust",
      size: 5 + Math.random() * 9,
      rot: 0,
    });
  }
}

export function stepParticles(ps: Particle[]) {
  for (let i = ps.length - 1; i >= 0; i--) {
    const p = ps[i];
    p.life++;
    p.x += p.vx;
    p.y += p.vy;
    if (p.kind === "ink") {
      p.vy -= 0.18;
      p.vx *= 0.97;
      p.vy *= 0.97;
    } else if (p.kind === "dust") {
      p.vx *= 0.94;
      p.vy *= 0.96;
      p.size *= 1.018;
    } else if (p.kind === "sweat") {
      p.vy -= 0.22;
    }
    if (p.life > p.max) ps.splice(i, 1);
  }
}

export function drawParticles(ctx: CanvasRenderingContext2D, ps: Particle[], c: Cam) {
  ctx.save();
  for (const p of ps) {
    const t = 1 - p.life / p.max;
    const X = sx(p.x, c);
    const Y = sy(p.y, c);
    ctx.globalAlpha = clamp(t, 0, 1) * (p.kind === "dust" ? 0.4 : 0.9);
    if (p.kind === "ink") {
      ctx.fillStyle = INK;
      ctx.beginPath();
      ctx.ellipse(X, Y, p.size * c.z * 1.1, p.size * c.z * 0.75, p.rot + p.life * 0.1, 0, TAU);
      ctx.fill();
    } else if (p.kind === "sweat") {
      ctx.fillStyle = INDIGO;
      ctx.beginPath();
      ctx.ellipse(X, Y, p.size * c.z * 0.8, p.size * c.z * 0.5, 0, 0, TAU);
      ctx.fill();
    } else {
      ctx.fillStyle = PAPER3;
      ctx.beginPath();
      ctx.ellipse(X, Y, p.size * c.z, p.size * c.z * 0.6, 0, 0, TAU);
      ctx.fill();
    }
  }
  ctx.restore();
}

/** Radial impact star — the classic animation contact frame. */
export function drawImpactFlash(ctx: CanvasRenderingContext2D, x: number, y: number, c: Cam, t: number, heavy: boolean) {
  const X = sx(x, c);
  const Y = sy(y, c);
  const R = (heavy ? 58 : 34) * (1 - t) * c.z + 6;
  ctx.save();
  ctx.globalAlpha = clamp(t * 1.6, 0, 1);
  ctx.translate(X, Y);
  ctx.fillStyle = PAPER;
  ctx.strokeStyle = CINNABAR;
  ctx.lineWidth = 2;
  ctx.beginPath();
  const spikes = heavy ? 8 : 6;
  for (let i = 0; i < spikes * 2; i++) {
    const a = (i / (spikes * 2)) * TAU;
    const rr = i % 2 === 0 ? R : R * 0.42;
    const px = Math.cos(a) * rr;
    const py = Math.sin(a) * rr;
    i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
  }
  ctx.closePath();
  ctx.fill();
  ctx.stroke();
  ctx.restore();
}

export function drawEventLabel(ctx: CanvasRenderingContext2D, ev: Ev, c: Cam, age: number) {
  const t = clamp(1 - age / 46, 0, 1);
  if (t <= 0) return;
  const X = sx(ev.x, c);
  const Y = sy(ev.y, c) - 26 - age * 0.55;
  ctx.save();
  ctx.globalAlpha = clamp(t * 1.4, 0, 1);
  ctx.textAlign = "center";
  const col = ev.kind === "block" || ev.kind === "parry" ? INDIGO : CINNABAR;
  ctx.fillStyle = col;
  ctx.font = `700 ${ev.heavy ? 22 : 16}px 'Barlow Condensed', sans-serif`;
  ctx.fillText(ev.text, X, Y);
  ctx.strokeStyle = col;
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(X - 26, Y + 5);
  ctx.lineTo(X + 26, Y + 5);
  ctx.stroke();
  ctx.restore();
}

export function drawDebug(ctx: CanvasRenderingContext2D, s: Sim, c: Cam) {
  ctx.save();
  ctx.lineWidth = 1;
  for (const f of s.f) {
    const r = worldRig(f.cur, f.facing);
    ctx.strokeStyle = f.id === 0 ? "rgba(193,39,45,0.7)" : "rgba(46,74,107,0.7)";
    const zones: [Pt, Pt][] = [
      [r.head, r.head],
      [r.neck, r.pelvis],
      [r.hipN, r.ftN],
      [r.hipF, r.ftF],
    ];
    for (const [a, b] of zones) {
      ctx.beginPath();
      ctx.arc(sx(a.x, c), sy(a.y, c), (a === b ? 16 : 14) * c.z, 0, TAU);
      ctx.stroke();
    }
    ctx.fillStyle = "rgba(27,24,21,0.7)";
    ctx.font = "600 10px 'Barlow Condensed', monospace";
    ctx.fillText(`BAL ${f.bal.toFixed(0)}  GRD ${f.grd.toFixed(0)}`, sx(f.cur.x, c) - 34, sy(196, c));
    // velocity vector
    ctx.strokeStyle = "rgba(193,39,45,0.8)";
    ctx.beginPath();
    ctx.moveTo(sx(f.cur.x, c), sy(90, c));
    ctx.lineTo(sx(f.cur.x + f.vel * 14, c), sy(90, c));
    ctx.stroke();
  }
  ctx.restore();
}

export function drawFighterLabel(ctx: CanvasRenderingContext2D, f: Fighter, c: Cam, sub: string) {
  const X = sx(f.cur.x, c);
  const Y = sy(210, c);
  ctx.save();
  ctx.textAlign = "center";
  ctx.fillStyle = "rgba(27,24,21,0.75)";
  ctx.font = "700 12px 'Barlow Condensed', sans-serif";
  ctx.fillText(f.name, X, Y);
  if (sub) {
    ctx.fillStyle = f.accent;
    ctx.font = "600 10px 'Barlow Condensed', sans-serif";
    ctx.fillText(sub, X, Y + 12);
  }
  ctx.restore();
}

export const COLORS = { INK, INK2, PAPER, PAPER2, PAPER3, CINNABAR, INDIGO };
