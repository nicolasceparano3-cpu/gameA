import { useCallback, useEffect, useState } from "react";
import Title from "./components/Title";
import Fight from "./components/Fight";
import Replay from "./components/Replay";
import { ARTS, MODES, OPPONENTS, type ModeId } from "./game/content";
import { newSim, type Sim } from "./game/engine";
import { initAudio } from "./game/audio";

const ART_KEY = "jiezou.arts.v1";
const LIB_KEY = "jiezou.replays.v1";

const STARTER_ARTS = ["ghost", "iron", "explosive"];

export interface Record {
  id: string;
  mode: ModeId;
  oppId: string;
  oppName: string;
  date: string;
  winner: 0 | 1 | null;
  rounds: number;
  log: Sim["log"];
}

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}
function save(key: string, val: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(val));
  } catch {
    /* quota — the fight still lives in memory for this session */
  }
}

type Screen = { k: "title" } | { k: "fight" } | { k: "replay"; sim: Sim; oppId: string; mode: ModeId };

export default function App() {
  const [screen, setScreen] = useState<Screen>({ k: "title" });
  const [mode, setMode] = useState<ModeId>("duel");
  const [oppId, setOppId] = useState(OPPONENTS[0].id);
  const [challengeIdx, setChallengeIdx] = useState(0);
  const [unlocked, setUnlocked] = useState<string[]>(() => {
    const saved = load<string[] | null>(ART_KEY, null);
    return saved && saved.length ? saved : STARTER_ARTS;
  });
  const [library, setLibrary] = useState<Record[]>(() => load<Record[]>(LIB_KEY, []));
  const [saved, setSaved] = useState(false);
  const [trainingPassive, setTrainingPassive] = useState(true);
  const [session, setSession] = useState(0);

  useEffect(() => save(ART_KEY, unlocked), [unlocked]);
  useEffect(() => save(LIB_KEY, library.slice(0, 4)), [library]);

  const opp = OPPONENTS.find((o) => o.id === oppId) ?? OPPONENTS[0];

  const startFight = (m: ModeId, id: string) => {
    initAudio();
    setMode(m);
    setOppId(id);
    setChallengeIdx(0);
    setSaved(false);
    setSession((s) => s + 1);
    setScreen({ k: "fight" });
  };

  const onFinished = useCallback(
    (sim: Sim) => {
      const rec: Record = {
        id: `${Date.now()}`,
        mode,
        oppId,
        oppName: opp.en,
        date: new Date().toLocaleString(),
        winner: sim.winner,
        rounds: sim.turn,
        log: sim.log,
      };
      setLibrary((l) => [rec, ...l].slice(0, 12));
      setScreen({ k: "replay", sim, oppId, mode });
    },
    [mode, oppId, opp.en]
  );

  const saveReplay = useCallback(() => {
    setSaved(true);
    setLibrary((l) => {
      const next = l.slice();
      if (next.length) next[0] = { ...next[0] };
      return next;
    });
  }, []);

  const exitReplay = useCallback(() => {
    if (mode === "challenge") {
      const last = library[0];
      if (last && last.winner === 0 && challengeIdx < OPPONENTS.length - 1) {
        const nextIdx = challengeIdx + 1;
        setChallengeIdx(nextIdx);
        setOppId(OPPONENTS[nextIdx].id);
        setSaved(false);
        setSession((s) => s + 1);
        setScreen({ k: "fight" });
        return;
      }
    }
    setScreen({ k: "title" });
  }, [mode, library, challengeIdx]);

  // award arts after a fight
  const award = (winner: 0 | 1 | null) => {
    if (winner !== 0) return;
    const locked = ARTS.filter((a) => !unlocked.includes(a.id));
    if (!locked.length) return;
    const gain = locked.slice(0, 2).map((a) => a.id);
    setUnlocked((u) => Array.from(new Set([...u, ...gain])));
  };

  if (screen.k === "title") {
    return (
      <Title
        onStart={startFight}
        onReplay={() => {
          const last = library[0];
          if (!last) return;
          const sim = newSim(last.mode, last.oppName, "錄", "#1B1815");
          sim.log = last.log;
          sim.winner = last.winner;
          sim.turn = last.rounds;
          setMode(last.mode);
          setOppId(last.oppId);
          setScreen({ k: "replay", sim, oppId: last.oppId, mode: last.mode });
        }}
        libraryCount={library.length}
        unlocked={unlocked.length}
      />
    );
  }

  if (screen.k === "fight") {
    return (
      <Fight
        key={session}
        mode={mode}
        opp={opp}
        unlocked={unlocked}
        trainingPassive={trainingPassive}
        onTogglePassive={() => setTrainingPassive((p) => !p)}
        onExit={() => setScreen({ k: "title" })}
        onFinished={(sim) => {
          award(sim.winner);
          onFinished(sim);
        }}
      />
    );
  }

  return (
    <Replay
      sim={screen.sim}
      opp={OPPONENTS.find((o) => o.id === screen.oppId) ?? OPPONENTS[0]}
      modeLabel={MODES.find((m) => m.id === screen.mode)?.en ?? "DUEL"}
      onExit={exitReplay}
      onSave={() => {
        saveReplay();
        award(screen.sim.winner);
      }}
      saved={saved}
    />
  );
}
