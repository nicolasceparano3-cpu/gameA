import { useState } from "react";
import { MODES, OPPONENTS, type ModeId } from "../game/content";
import titleHall from "../assets/title-hall.jpg";

export function Seal({ className = "", size = 96 }: { className?: string; size?: number }) {
  // Hand-drawn cinnabar chop: a squared seal with a stylised fist-and-wrist glyph.
  return (
    <svg viewBox="0 0 100 100" width={size} height={size} className={className} aria-label="Seal mark">
      <path
        d="M6.5 5.5 H93.5 V78 C93.5 84 89 89 83 90.5 L78 94.5 H6.5 Z"
        fill="#C1272D"
      />
      <path
        d="M13 12 H87 V76.5 C87 81 84 84.5 79.5 86 L76 87.5 H13 Z"
        fill="none"
        stroke="#E8DFCE"
        strokeWidth="2.4"
      />
      {/* wrist */}
      <path d="M20 62 H44 V79 H20 Z" fill="#E8DFCE" />
      {/* forearm rising to the knuckle block */}
      <path d="M27 38 H51 V63 H27 Z" fill="#E8DFCE" />
      {/* knuckles: four bars */}
      <path d="M27 21 H50 V27 H27 Z" fill="#E8DFCE" />
      <path d="M27 29.5 H50 V35.5 H27 Z" fill="#E8DFCE" />
      <path d="M53 27 H62 V47 H53 Z" fill="#E8DFCE" />
      {/* thumb hook */}
      <path d="M52 45 Q67 47 64 60 Q62 67 52 66 Z" fill="#E8DFCE" />
      {/* counter-stroke */}
      <path d="M70 20 H76 V70 H70 Z" fill="#E8DFCE" opacity="0.92" />
      <path d="M67 73 H79 V79 H67 Z" fill="#E8DFCE" />
    </svg>
  );
}

interface Props {
  onStart: (mode: ModeId, oppId: string) => void;
  onReplay: () => void;
  libraryCount: number;
  unlocked: number;
}

export default function Title({ onStart, onReplay, libraryCount, unlocked }: Props) {
  const [mode, setMode] = useState<ModeId | null>(null);
  const [opp, setOpp] = useState(OPPONENTS[0].id);

  const chosen = MODES.find((m) => m.id === mode);

  return (
    <div className="relative h-full w-full overflow-y-auto overflow-x-hidden bg-paper text-ink">
      {/* plate */}
      <div className="pointer-events-none fixed inset-0">
        <img src={titleHall} alt="" className="h-full w-full object-cover opacity-[0.72] mix-blend-multiply" />
        <div className="absolute inset-0 bg-gradient-to-r from-paper via-paper/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-paper via-transparent to-paper/40" />
      </div>

      <div className="relative mx-auto flex min-h-full w-full max-w-[1440px] flex-col gap-10 px-6 py-10 lg:px-14">
        <header className="flex items-start justify-between gap-6">
          <div className="rise">
            <div className="mb-3 flex items-center gap-3">
              <span className="h-px w-10 bg-ink/60" />
              <span className="font-hud text-[11px] font-600 tracking-[0.42em] text-ink-3">POSE · PHYSICS · REPLAY</span>
            </div>
            <h1 className="font-display text-[clamp(72px,15vw,190px)] font-900 leading-[0.78] tracking-[-0.03em]">
              節奏
            </h1>
            <div className="mt-4 flex flex-wrap items-baseline gap-x-5 gap-y-1">
              <span className="font-hud text-[clamp(24px,4vw,46px)] font-700 uppercase leading-none tracking-[0.14em]">
                Jiézòu
              </span>
              <span className="font-hud text-[13px] font-600 uppercase tracking-[0.5em] text-cinnabar">
                Rhythm of the Fist
              </span>
            </div>
            <p className="mt-6 max-w-[46ch] font-hud text-[17px] leading-[1.5] text-ink-2">
              You do not choose <em className="not-italic text-cinnabar">Punch</em>. You raise his left hand, turn the
              torso, shift the weight onto the front leg and drive a fist at the jaw — then both plans collide at once.
            </p>
          </div>

          <div className="hidden shrink-0 sm:block">
            <div className="stamp">
              <Seal size={112} />
            </div>
            <div className="mt-3 text-right font-hud text-[11px] uppercase tracking-[0.3em] text-ink-3">
              {unlocked} arts learned
            </div>
          </div>
        </header>

        {/* modes — an editorial list, not a card grid */}
        <section className="mt-auto">
          <div className="mb-4 flex items-baseline justify-between border-b border-ink/25 pb-2">
            <h2 className="font-hud text-[12px] font-700 uppercase tracking-[0.4em]">Select discipline</h2>
            <span className="font-hud text-[12px] tracking-[0.2em] text-ink-3">0{MODES.length} MODES</span>
          </div>

          <ul className="grid gap-px bg-ink/15">
            {MODES.map((m, i) => {
              const active = mode === m.id;
              const isReplay = m.id === "replay";
              return (
                <li key={m.id}>
                  <button
                    disabled={isReplay && libraryCount === 0}
                    onClick={() => (isReplay ? onReplay() : setMode(m.id))}
                    className={`group flex w-full items-center gap-5 bg-paper/85 px-4 py-3.5 text-left transition-all duration-200 hover:bg-paper ${
                      active ? "bg-paper" : ""
                    }`}
                  >
                    <span
                      className={`grid h-12 w-12 shrink-0 place-items-center font-display text-2xl font-900 transition-colors ${
                        active ? "bg-cinnabar text-paper" : "bg-ink/8 text-ink group-hover:bg-ink group-hover:text-paper"
                      }`}
                    >
                      {m.cn}
                    </span>
                    <span className="min-w-0 flex-1">
                      <span className="flex items-baseline gap-3">
                        <span className="font-hud text-lg font-700 uppercase tracking-[0.16em]">{m.en}</span>
                        <span className="font-hud text-[10px] tracking-[0.3em] text-ink-3">
                          {String(i + 1).padStart(2, "0")}
                        </span>
                        {isReplay && libraryCount === 0 && (
                          <span className="font-hud text-[10px] tracking-[0.2em] text-ink-3">NO SAVED FIGHTS YET</span>
                        )}
                        {isReplay && libraryCount > 0 && (
                          <span className="font-hud text-[10px] tracking-[0.2em] text-cinnabar">
                            {libraryCount} SAVED
                          </span>
                        )}
                      </span>
                      <span className="mt-0.5 block font-hud text-[14px] leading-snug text-ink-3">{m.blurb}</span>
                    </span>
                    <span
                      className={`h-1 w-0 shrink-0 bg-cinnabar transition-all duration-300 group-hover:w-14 ${
                        active ? "w-14" : ""
                      }`}
                    />
                  </button>
                </li>
              );
            })}
          </ul>
        </section>

        {/* opponent select — appears once a mode is chosen */}
        {chosen && chosen.id !== "replay" && (
          <section className="rise border-t border-ink/25 pt-6">
            <div className="mb-4 flex items-baseline justify-between">
              <h2 className="font-hud text-[12px] font-700 uppercase tracking-[0.4em]">Choose your opponent</h2>
              <span className="font-hud text-[12px] tracking-[0.2em] text-ink-3">
                {chosen.cn} · {chosen.en}
              </span>
            </div>
            <div className="grid gap-px bg-ink/15 sm:grid-cols-2 lg:grid-cols-3">
              {OPPONENTS.map((o) => {
                const on = opp === o.id;
                return (
                  <button
                    key={o.id}
                    onClick={() => setOpp(o.id)}
                    className={`flex gap-4 px-4 py-4 text-left transition-colors ${
                      on ? "bg-ink text-paper" : "bg-paper/85 hover:bg-paper"
                    }`}
                  >
                    <span
                      className="grid h-14 w-14 shrink-0 place-items-center rounded-full border-2 font-display text-2xl font-900"
                      style={{ borderColor: on ? "#E8DFCE" : o.accent, color: on ? "#E8DFCE" : o.accent }}
                    >
                      {o.cn}
                    </span>
                    <span className="min-w-0">
                      <span className="block font-hud text-[15px] font-700 uppercase tracking-[0.14em]">{o.en}</span>
                      <span
                        className="block font-hud text-[11px] uppercase tracking-[0.24em]"
                        style={{ color: on ? "#BCAB8B" : o.accent }}
                      >
                        {o.title}
                      </span>
                      <span className={`mt-1 block font-hud text-[13px] leading-snug ${on ? "text-paper-3" : "text-ink-3"}`}>
                        {o.bio}
                      </span>
                      <span className="mt-2 flex gap-3">
                        {(["dmg", "def", "spd", "bal"] as const).map((k) => (
                          <span key={k} className="flex flex-col items-start gap-1">
                            <span className={`font-hud text-[9px] tracking-[0.2em] ${on ? "text-paper-3" : "text-ink-3"}`}>
                              {k.toUpperCase()}
                            </span>
                            <span className="flex gap-[2px]">
                              {Array.from({ length: 10 }).map((_, i) => (
                                <span
                                  key={i}
                                  className="block h-3 w-[3px]"
                                  style={{
                                    background:
                                      i < o.stats[k]
                                        ? on
                                          ? "#E8DFCE"
                                          : o.accent
                                        : on
                                          ? "rgba(232,223,206,0.22)"
                                          : "rgba(27,24,21,0.15)",
                                  }}
                                />
                              ))}
                            </span>
                          </span>
                        ))}
                      </span>
                    </span>
                  </button>
                );
              })}
            </div>

            <div className="mt-6 flex flex-wrap items-center gap-4">
              <button
                onClick={() => onStart(chosen.id, opp)}
                className="group relative overflow-hidden bg-cinnabar px-10 py-4 font-hud text-[15px] font-700 uppercase tracking-[0.34em] text-paper transition-all hover:bg-cinnabar-d"
              >
                Enter the hall
                <span className="absolute inset-y-0 left-0 w-1.5 bg-ink/0 transition-all group-hover:bg-ink/40" />
              </button>
              <p className="font-hud text-[12px] uppercase tracking-[0.24em] text-ink-3">
                Plan → Preview → Commit → Resolve
              </p>
            </div>
          </section>
        )}

        <footer className="mt-4 flex flex-wrap items-center justify-between gap-4 border-t border-ink/25 pt-4 font-hud text-[11px] uppercase tracking-[0.3em] text-ink-3">
          <span>Drag the ghost · Wheel rotates · Right-click swaps fist &amp; palm</span>
          <span>Space preview · Enter commit · 1–9 arts</span>
        </footer>
      </div>
    </div>
  );
}
