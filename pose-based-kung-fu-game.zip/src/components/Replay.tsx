import { useCallback, useEffect, useRef, useState } from "react";
import type { Frame, Sim } from "../game/engine";
import type { Opponent } from "../game/content";
import { drawFighter, drawStage, drawImpactFlash, drawEventLabel, drawParticles, stepParticles, type Cam, type Particle, COLORS } from "../game/render";
import paperImg from "../assets/paper.jpg";
import stageImg from "../assets/stage-back.jpg";
import { initAudio, play } from "../game/audio";

const SEAL_CHAR: Record<string, string> = {
  hit: "擊",
  block: "格",
  parry: "化",
  clash: "撞",
  fall: "倒",
  break: "破",
  stumble: "跌",
  push: "按",
  whiff: "空",
};

function useImg(src: string) {
  const ref = useRef<HTMLImageElement | null>(null);
  const [, bump] = useState(0);
  useEffect(() => {
    const im = new Image();
    im.onload = () => {
      ref.current = im;
      bump((n) => n + 1);
    };
    im.src = src;
  }, [src]);
  return ref;
}

interface Props {
  sim: Sim;
  opp: Opponent;
  modeLabel: string;
  onExit: () => void;
  onSave: () => void;
  saved: boolean;
}

export default function Replay({ sim, opp, modeLabel, onExit, onSave, saved }: Props) {
  const [stage, setStage] = useState<"scroll" | "cinema">("scroll");
  const scrollRef = useRef<HTMLCanvasElement>(null);
  const playRef = useRef<HTMLCanvasElement>(null);
  const log = sim.log;

  const paper = useImg(paperImg);
  const bg = useImg(stageImg);

  // ── handscroll interstitial ────────────────────────────────────────────
  const offRef = useRef(0);
  const dragRef = useRef<{ on: boolean; x: number; start: number }>({ on: false, x: 0, start: 0 });

  useEffect(() => {
    if (stage !== "scroll") return;
    let raf = 0;
    let t0 = performance.now();
    const loop = (t: number) => {
      const c = scrollRef.current;
      if (c) {
        const w = c.clientWidth;
        const h = c.clientHeight;
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        if (c.width !== w * dpr || c.height !== h * dpr) {
          c.width = w * dpr;
          c.height = h * dpr;
        }
        const ctx = c.getContext("2d")!;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
        const el = (t - t0) / 1000;
        const N = Math.max(7, Math.min(18, Math.floor(log.length / 110) + 6));
        const panelW = Math.max(230, Math.min(340, w / 4));
        const VW = panelW * N;
        const maxOff = Math.max(0, VW - w);
        if (!dragRef.current.on) {
          const target = Math.min(maxOff, el * 118);
          offRef.current += (target - offRef.current) * 0.06;
        }
        const off = offRef.current;

        ctx.fillStyle = COLORS.PAPER;
        ctx.fillRect(0, 0, w, h);
        if (paper.current) {
          ctx.globalAlpha = 0.55;
          ctx.globalCompositeOperation = "multiply";
          const ts = 400;
          for (let x = 0; x < w; x += ts) for (let y = 0; y < h; y += ts) ctx.drawImage(paper.current, x, y, ts, ts);
          ctx.globalCompositeOperation = "source-over";
          ctx.globalAlpha = 1;
        }

        const top = h * 0.14;
        const bot = h * 0.86;
        // scroll rules
        ctx.strokeStyle = "rgba(27,24,21,0.35)";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(0, top);
        ctx.lineTo(w, top);
        ctx.moveTo(0, bot);
        ctx.lineTo(w, bot);
        ctx.stroke();

        const scale = Math.min((panelW * 0.92) / 430, (bot - top) / 205);
        const reveal = Math.min(1, el / 2.2);

        for (let i = 0; i < N; i++) {
          const gi = Math.min(log.length - 1, Math.round((i / (N - 1)) * (log.length - 1)));
          const f = log[gi];
          if (!f) continue;
          const px = i * panelW + panelW / 2 - off;
          if (px < -panelW || px > w + panelW) continue;
          const app = Math.min(1, Math.max(0, reveal * N - i));
          if (app <= 0) continue;

          ctx.save();
          ctx.globalAlpha = app;
          ctx.translate(px, top + (bot - top) * 0.5 + (1 - app) * 14);
          const cam: Cam = { z: scale * (0.9 + app * 0.1), cx: (f.a.x + f.b.x) / 2, gy: 62, shake: 0 };
          drawFighter(ctx, f.a, 1, cam, { mode: "solid", accent: "#C1272D" });
          drawFighter(ctx, f.b, -1, cam, { mode: "solid", accent: opp.accent });
          ctx.restore();

          // impact seals
          const heavy = f.evs.find((e) => e.heavy || e.kind === "parry" || e.kind === "fall");
          if (heavy && app > 0.6) {
            const sxp = px + scale * 60;
            const syp = top + (bot - top) * (0.2 + (i % 3) * 0.2);
            ctx.save();
            ctx.translate(sxp, syp);
            ctx.rotate(-0.11);
            const s = 34;
            ctx.globalAlpha = Math.min(1, (app - 0.6) * 3);
            ctx.fillStyle = "#C1272D";
            ctx.fillRect(-s / 2, -s / 2, s, s);
            ctx.fillStyle = "#E8DFCE";
            ctx.font = "900 24px 'Noto Serif SC', serif";
            ctx.textAlign = "center";
            ctx.textBaseline = "middle";
            ctx.fillText(SEAL_CHAR[heavy.kind] || "擊", 0, 1);
            ctx.restore();
          }
          // panel tick
          ctx.strokeStyle = "rgba(27,24,21,0.14)";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(px - panelW / 2, top);
          ctx.lineTo(px - panelW / 2, bot);
          ctx.stroke();
        }

        // rollers
        ctx.fillStyle = "#3A342C";
        ctx.fillRect(0, 0, 14, h);
        ctx.fillRect(w - 14, 0, 14, h);

        ctx.fillStyle = "rgba(27,24,21,0.72)";
        ctx.textAlign = "left";
        ctx.font = "700 12px 'Barlow Condensed', sans-serif";
        ctx.fillText("THE FIGHT, READ LEFT TO RIGHT", 30, 26);
        ctx.textAlign = "right";
        ctx.font = "600 11px 'Barlow Condensed', sans-serif";
        ctx.fillStyle = "#C1272D";
        ctx.fillText(`${log.filter((f) => f.evs.length).length} EXCHANGES RECORDED`, w - 30, 26);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [stage, log, opp.accent, paper]);

  // auto-advance to the cinematic
  useEffect(() => {
    if (stage !== "scroll") return;
    const t = setTimeout(() => {
      initAudio();
      setStage("cinema");
    }, 6000);
    return () => clearTimeout(t);
  }, [stage]);

  // ── cinematic ──────────────────────────────────────────────────────────
  const [idx, setIdx] = useState(0);
  const [playing, setPlaying] = useState(true);
  const [speed, setSpeed] = useState(1);
  const [camMode, setCamMode] = useState<"cinema" | "p1" | "p2">("cinema");
  const idxRef = useRef(0);
  const accRef = useRef(0);
  const partsRef = useRef<Particle[]>([]);
  const flashesRef = useRef<{ x: number; y: number; t: number; heavy: boolean }[]>([]);
  const labelsRef = useRef<{ ev: Frame["evs"][0]; age: number }[]>([]);
  const freezeRef = useRef(0);

  const goto = useCallback((n: number) => {
    idxRef.current = Math.max(0, Math.min(log.length - 1, n));
    setIdx(idxRef.current);
  }, [log.length]);

  useEffect(() => {
    if (stage !== "cinema") return;
    let raf = 0;
    let last = performance.now();
    // never run the cinematic against an empty recording
    const F: Frame[] = log.length
      ? log
      : [{ a: sim.f[0].cur, b: sim.f[1].cur, evs: [], shake: 0, hp: [100, 100], bal: [100, 100] }];
    const loop = (t: number) => {
      const dt = Math.min(64, t - last);
      last = t;
      const c = playRef.current;
      if (c) {
        const w = c.clientWidth;
        const h = c.clientHeight;
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        if (c.width !== w * dpr || c.height !== h * dpr) {
          c.width = w * dpr;
          c.height = h * dpr;
        }
        const ctx = c.getContext("2d")!;
        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);

        if (playing && freezeRef.current <= 0) {
          // slow down approaching a heavy impact
          let sf = speed;
          const f0 = log[idxRef.current];
          const near = log.slice(idxRef.current, idxRef.current + 16).some((f) => f.evs.some((e) => e.heavy));
          if (near && speed >= 1) sf = 0.32;
          accRef.current += (dt / 1000) * 60 * sf;
          while (accRef.current >= 1) {
            accRef.current -= 1;
            const f = log[idxRef.current];
            if (f) {
              for (const ev of f.evs) {
                flashesRef.current.push({ x: ev.x, y: ev.y, t: 0, heavy: ev.heavy });
                labelsRef.current.push({ ev, age: 0 });
                const k = ev.kind === "hit" ? "hit" : (ev.kind as "block" | "parry" | "clash" | "stumble" | "fall" | "break");
                play(k, ev.power);
                if (ev.heavy) freezeRef.current = 7;
              }
            }
            if (idxRef.current >= log.length - 1) {
              setPlaying(false);
              break;
            }
            idxRef.current++;
          }
          setIdx(idxRef.current);
          void f0;
        }
        if (freezeRef.current > 0) freezeRef.current--;

        // draw
        const f = log[Math.min(log.length - 1, idxRef.current)];
        const mid = (f.a.x + f.b.x) / 2;
        const gap = Math.abs(f.a.x - f.b.x);
        let z = Math.min(w / (gap + 330), h / 250);
        let cx = mid;
        if (camMode === "p1") {
          cx = f.a.x + 26;
          z = Math.min(w / 460, h / 235) * 1.15;
        } else if (camMode === "p2") {
          cx = f.b.x - 26;
          z = Math.min(w / 460, h / 235) * 1.15;
        } else {
          const heavyNear = flashesRef.current.some((fl) => fl.heavy && fl.t < 8);
          if (heavyNear) z *= 1.22;
          cx += Math.sin(idxRef.current * 0.013) * 26;
        }
        const cam: Cam = { z, cx, gy: h * 0.8, shake: f.shake };

        drawStage(ctx, w, h, cam, bg.current, paper.current);

        ctx.save();
        const sh = f.shake;
        if (sh > 0) ctx.translate((Math.random() - 0.5) * sh * 4, (Math.random() - 0.5) * sh * 3);

        // motion trails
        if (speed >= 1) {
          for (let k = 3; k >= 1; k--) {
            const pf = log[Math.max(0, idxRef.current - k * 2)];
            if (!pf) continue;
            ctx.globalAlpha = 0.07 * (4 - k);
            drawFighter(ctx, pf.a, 1, cam, { mode: "solid", accent: "#C1272D" });
            drawFighter(ctx, pf.b, -1, cam, { mode: "solid", accent: opp.accent });
          }
          ctx.globalAlpha = 1;
        }

          drawFighter(ctx, f.a, 1, cam, { mode: "solid", accent: "#C1272D" });
          drawFighter(ctx, f.b, -1, cam, { mode: "solid", accent: opp.accent });
          ctx.restore();

          // effects
        for (let i = flashesRef.current.length - 1; i >= 0; i--) {
          const fl = flashesRef.current[i];
          fl.t += 0.045;
          if (fl.t > 1) flashesRef.current.splice(i, 1);
          else drawImpactFlash(ctx, fl.x, fl.y, cam, fl.t, fl.heavy);
        }
        drawParticles(ctx, partsRef.current, cam);
        stepParticles(partsRef.current);
        for (let i = labelsRef.current.length - 1; i >= 0; i--) {
          const l = labelsRef.current[i];
          l.age += 1;
          if (l.age > 50) labelsRef.current.splice(i, 1);
          else drawEventLabel(ctx, l.ev, cam, l.age);
        }

        // letterbox
        ctx.fillStyle = "#1B1815";
        const bar = Math.round(h * 0.075);
        ctx.fillRect(0, 0, w, bar);
        ctx.fillRect(0, h - bar, w, bar);
        ctx.fillStyle = "rgba(232,223,206,0.7)";
        ctx.font = "600 11px 'Barlow Condensed', sans-serif";
        ctx.textAlign = "left";
        ctx.fillText(`${modeLabel} · ${opp.en}`, 18, bar - 10);
        ctx.textAlign = "right";
        ctx.fillText(`FRAME ${idxRef.current}/${log.length - 1}`, w - 18, bar - 10);
      }
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [stage, playing, speed, camMode, log, opp, modeLabel, bg, paper]);

  const scrollDrag = (e: React.PointerEvent) => {
    if (!dragRef.current.on) return;
    offRef.current = Math.max(0, dragRef.current.start - (e.clientX - dragRef.current.x));
  };

  const result = sim.winner === 0 ? "VICTORY" : sim.winner === 1 ? "DEFEAT" : "DRAW";

  return (
    <div className="relative h-full w-full overflow-hidden bg-paper">
      {stage === "scroll" ? (
        <>
          <canvas
            ref={scrollRef}
            className="absolute inset-0 h-full w-full touch-none"
            onPointerDown={(e) => {
              (e.target as HTMLElement).setPointerCapture(e.pointerId);
              dragRef.current = { on: true, x: e.clientX, start: offRef.current };
            }}
            onPointerMove={scrollDrag}
            onPointerUp={() => (dragRef.current.on = false)}
            onPointerCancel={() => (dragRef.current.on = false)}
          />
          <div className="absolute inset-x-0 bottom-0 flex flex-col items-center gap-4 pb-8">
            <div className="stamp bg-cinnabar px-6 py-2 font-display text-3xl font-900 text-paper">
              {result}
              <span className="ml-3 font-hud text-sm font-600 tracking-[0.3em]">{sim.winner === 0 ? "你" : opp.cn}</span>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-3">
              <button
                onClick={() => {
                  initAudio();
                  setStage("cinema");
                }}
                className="bg-ink px-7 py-3 font-hud text-[13px] font-700 uppercase tracking-[0.3em] text-paper transition-colors hover:bg-cinnabar"
              >
                Play cinematic ▸
              </button>
              <button
                onClick={onSave}
                disabled={saved}
                className="border border-ink/40 px-6 py-3 font-hud text-[13px] font-700 uppercase tracking-[0.26em] transition-colors hover:bg-ink hover:text-paper disabled:opacity-45"
              >
                {saved ? "Saved ✓" : "Save replay"}
              </button>
              <button
                onClick={onExit}
                className="border border-ink/40 px-6 py-3 font-hud text-[13px] font-700 uppercase tracking-[0.26em] transition-colors hover:bg-ink hover:text-paper"
              >
                Leave hall
              </button>
            </div>
            <p className="font-hud text-[11px] uppercase tracking-[0.3em] text-ink-3">Drag the scroll · auto-plays in a moment</p>
          </div>
        </>
      ) : (
        <>
          <canvas ref={playRef} className="absolute inset-0 h-full w-full" />
          <div className="absolute inset-x-0 bottom-0 flex flex-wrap items-center justify-center gap-2 bg-ink/92 px-4 py-3">
            <Ctl onClick={() => setPlaying((p) => !p)} active={playing}>
              {playing ? "❚❚ Pause" : "▸ Play"}
            </Ctl>
            <Ctl onClick={() => goto(0)}>⟲ Restart</Ctl>
            <Ctl onClick={() => goto(idx - 60)}>‹‹ −1s</Ctl>
            <Ctl onClick={() => goto(idx + 60)}>+1s ››</Ctl>
            <span className="mx-2 h-6 w-px bg-paper/25" />
            {[0.25, 0.5, 1].map((s) => (
              <Ctl key={s} active={speed === s} onClick={() => setSpeed(s)}>
                {s === 1 ? "100%" : `${s * 100}%`}
              </Ctl>
            ))}
            <span className="mx-2 h-6 w-px bg-paper/25" />
            {(
              [
                ["cinema", "Cinematic"],
                ["p1", "Player 1"],
                ["p2", "Opponent"],
              ] as const
            ).map(([k, l]) => (
              <Ctl key={k} active={camMode === k} onClick={() => setCamMode(k)}>
                {l}
              </Ctl>
            ))}
            <span className="mx-2 h-6 w-px bg-paper/25" />
            <Ctl onClick={onSave} active={saved}>
              {saved ? "Saved ✓" : "Save"}
            </Ctl>
            <Ctl onClick={onExit}>Exit</Ctl>
          </div>
          <input
            type="range"
            min={0}
            max={Math.max(0, log.length - 1)}
            value={idx}
            onChange={(e) => {
              setPlaying(false);
              goto(Number(e.target.value));
            }}
            className="absolute inset-x-6 bottom-[72px] w-[min(680px,80%)] accent-[#C1272D]"
            aria-label="Scrub replay"
          />
        </>
      )}
    </div>
  );
}

function Ctl({ children, onClick, active }: { children: React.ReactNode; onClick: () => void; active?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-2 font-hud text-[12px] font-700 uppercase tracking-[0.2em] transition-colors ${
        active ? "bg-cinnabar text-paper" : "text-paper/70 hover:bg-paper/15 hover:text-paper"
      }`}
    >
      {children}
    </button>
  );
}


