import { useCallback, useEffect, useRef, useState } from "react";
import { ARTS, type ModeId, type Opponent } from "../game/content";
import {
  beginTurn,
  newSim,
  preview as runPreview,
  step,
  tagOf,
  STAGE,
  type Ev,
  type Plan,
  type PreviewResult,
  type Sim,
} from "../game/engine";
import { planAI } from "../game/ai";
import { clamp, clonePose, rig, type Focus, type Pose } from "../game/pose";
import {
  COLORS,
  drawContacts,
  drawDebug,
  drawEventLabel,
  drawFighter,
  drawFighterLabel,
  drawHandles,
  drawImpactFlash,
  drawParticles,
  drawStage,
  drawStrand,
  drawTrajectories,
  hitTest,
  makeCam,
  spawnDust,
  spawnImpact,
  stepParticles,
  type Cam,
  type Particle,
} from "../game/render";
import { initAudio, play } from "../game/audio";
import paperImg from "../assets/paper.jpg";
import stageImg from "../assets/stage-back.jpg";

type Phase = "plan" | "preview" | "resolve" | "second" | "ko" | "replay";

function useImg(src: string) {
  const ref = useRef<HTMLImageElement | null>(null);
  const [, bump] = useState(0);
  useEffect(() => {
    const im = new Image();
    im.onload = () => {
      ref.current = im;
      bump((n) => n + 1);
    };
    im.src = src;
  }, [src]);
  return ref;
}

const FOCUS_ORDER: Focus[] = ["handF", "handN", "footF", "footN", "torso", "root"];
const FOCUS_LABEL: Record<Focus, string> = {
  root: "ROOT / POSITION",
  torso: "TORSO / LEAN",
  handN: "LEAD HAND",
  handF: "REAR HAND",
  footN: "LEAD FOOT",
  footF: "REAR FOOT",
};

interface Props {
  mode: ModeId;
  opp: Opponent;
  unlocked: string[];
  onExit: () => void;
  onFinished: (sim: Sim) => void;
  trainingPassive: boolean;
  onTogglePassive: () => void;
}

export default function Fight({ mode, opp, unlocked, onExit, onFinished, trainingPassive, onTogglePassive }: Props) {
  const simRef = useRef<Sim | null>(null);
  if (!simRef.current) simRef.current = newSim(mode, opp.en, opp.cn, opp.accent);
  const sim = simRef.current;

  const canvasRef = useRef<HTMLCanvasElement>(null);
  const bg = useImg(stageImg);
  const paper = useImg(paperImg);

  const planRef = useRef<Pose>(clonePose(sim.f[0].cur));
  const [planVer, setPlanVer] = useState(0);
  const bump = () => setPlanVer((v) => v + 1);

  const [phase, setPhase] = useState<Phase>("plan");
  const phaseRef = useRef<Phase>("plan");
  const go = (p: Phase) => {
    phaseRef.current = p;
    setPhase(p);
  };

  const [focus, setFocus] = useState<Focus>("handF");
  const focusRef = useRef<Focus>("handF");
  const setF = (f: Focus) => {
    focusRef.current = f;
    setFocus(f);
  };

  const [tempo, setTempo] = useState(1);
  const tempoRef = useRef(1);
  const [activeArt, setActiveArt] = useState<string | null>(null);
  const artRef = useRef<string | null>(null);
  const [prevRes, setPrevRes] = useState<PreviewResult | null>(null);
  const [charges, setCharges] = useState<Record<string, number>>(() =>
    Object.fromEntries(ARTS.map((a) => [a.id, a.charges]))
  );
  const chargesRef = useRef(charges);
  chargesRef.current = charges;

  const aiPlanRef = useRef<Plan | null>(null);
  const armedArtRef = useRef<string | null>(null);

  const [hud, setHud] = useState({ hp: 100, sta: 100, bal: 100, grd: 100, oHp: 100, oBal: 100, oGrd: 100, turn: 1 });
  const turnLimit = mode === "training" || mode === "sandbox" ? 0 : mode === "master" ? 10 : mode === "challenge" ? 11 : 13;
  const [time, setTime] = useState(turnLimit);

  const fx = useRef({ parts: [] as Particle[], labels: [] as { ev: Ev; age: number }[], flashes: [] as { x: number; y: number; t: number; heavy: boolean }[] });
  const camRef = useRef<Cam>({ z: 1, cx: 600, gy: 0, shake: 0 });
  const prevP = useRef<[number, number]>([1, 1]);
  const commitRef = useRef<() => void>(() => {});

  const syncHud = useCallback(() => {
    const s = simRef.current!;
    setHud({
      hp: s.f[0].hp,
      sta: s.f[0].sta,
      bal: s.f[0].bal,
      grd: s.f[0].grd,
      oHp: s.f[1].hp,
      oBal: s.f[1].bal,
      oGrd: s.f[1].grd,
      turn: s.turn,
    });
  }, []);

  const startPlan = useCallback(() => {
    const s = simRef.current!;
    planRef.current = clonePose(s.f[0].cur);
    // the opponent has already decided — you just can't see it
    aiPlanRef.current =
      mode === "sandbox" || (mode === "training" && trainingPassive)
        ? { pose: clonePose(s.f[1].cur), tempo: 0.9, tag: "hold" }
        : planAI(s, s.f[1], s.f[0], opp, () => Math.random());
    setPrevRes(null);
    setActiveArt(null);
    artRef.current = null;
    setTime(turnLimit);
    syncHud();
    bump();
    go("plan");
  }, [mode, opp, syncHud, trainingPassive, turnLimit]);

  // fresh turn whenever we enter plan
  useEffect(() => {
    if (phase === "plan") {
      const s = simRef.current;
      if (s && !s.ended && aiPlanRef.current === null) startPlan();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── plan editing ────────────────────────────────────────────────────────
  const clampPlan = useCallback((p: Pose) => {
    const cur = simRef.current!.f[0].cur;
    const shadow = artRef.current === "shadow";
    const range = shadow ? 130 : 84;
    p.x = clamp(p.x, cur.x - range, cur.x + range);
    p.x = clamp(p.x, STAGE.left + 8, STAGE.right - 8);
    p.handN.x = clamp(p.handN.x, -70, 100);
    p.handF.x = clamp(p.handF.x, -70, 100);
    p.handN.y = clamp(p.handN.y, 3, 200);
    p.handF.y = clamp(p.handF.y, 3, 200);
    p.footN.x = clamp(p.footN.x, -75, 100);
    p.footF.x = clamp(p.footF.x, -75, 100);
    p.footN.y = clamp(p.footN.y, 0, 155);
    p.footF.y = clamp(p.footF.y, 0, 155);
    p.crouch = clamp(p.crouch, 0, 1);
    p.lean = clamp(p.lean, -0.62, 0.8);
    p.twist = clamp(p.twist, -0.9, 0.9);
    p.weight = clamp(p.weight, -1, 1);
  }, []);

  const edit = useCallback(
    (fn: (p: Pose) => void) => {
      const p = clonePose(planRef.current);
      fn(p);
      clampPlan(p);
      planRef.current = p;
      bump();
    },
    [clampPlan]
  );

  const toWorld = (e: PointerEvent | React.PointerEvent) => {
    const c = canvasRef.current!;
    const r = c.getBoundingClientRect();
    const cam = camRef.current;
    return {
      px: e.clientX - r.left,
      py: e.clientY - r.top,
      wx: cam.cx + (e.clientX - r.left - r.width / 2) / cam.z,
      wy: (cam.gy - (e.clientY - r.top)) / cam.z,
      w: r.width,
    };
  };

  const draggingRef = useRef<Focus | null>(null);

  const onPointerDown = (e: React.PointerEvent) => {
    initAudio();
    if (phaseRef.current !== "plan" && phaseRef.current !== "second") return;
    const { wx, wy } = toWorld(e);
    const h = hitTest(planRef.current, sim.f[0].facing, wx, wy);
    if (h) {
      setF(h);
      draggingRef.current = h;
      (e.target as HTMLElement).setPointerCapture(e.pointerId);
    }
  };

  const onPointerMove = (e: React.PointerEvent) => {
    if (!draggingRef.current) return;
    const { wx, wy } = toWorld(e);
    const f = draggingRef.current;
    const facing = sim.f[0].facing;
    edit((p) => {
      if (f === "root") {
        p.x = wx;
      } else if (f === "torso") {
        const hx = (wx - p.x) * facing;
        p.lean = clamp(hx / 95, -0.62, 0.8);
        p.crouch = clamp((172 - wy) / 74, 0, 1);
        p.weight = clamp(hx / 70, -1, 1);
      } else if (f === "handN") {
        p.handN = { x: (wx - p.x) * facing, y: wy };
      } else if (f === "handF") {
        p.handF = { x: (wx - p.x) * facing, y: wy };
      } else if (f === "footN") {
        p.footN = { x: (wx - p.x) * facing, y: Math.max(0, wy) };
      } else {
        p.footF = { x: (wx - p.x) * facing, y: Math.max(0, wy) };
      }
      // dragging a hand far forward commits weight with it
      if (f === "handN" || f === "handF") p.weight = clamp(p.weight * 0.9 + (f === "handF" ? 0.12 : 0.08), -1, 1);
    });
  };

  const onPointerUp = () => {
    draggingRef.current = null;
  };

  const rotateFocus = (d: number) => {
    const f = focusRef.current;
    edit((p) => {
      const r = rig(p);
      if (f === "handN" || f === "handF") {
        const s = f === "handN" ? r.shN : r.shF;
        const t = f === "handN" ? p.handN : p.handF;
        const dx = t.x - s.x;
        const dy = t.y - s.y;
        const ang = Math.atan2(dy, dx) + d;
        const len = Math.hypot(dx, dy);
        const nt = { x: s.x + Math.cos(ang) * len, y: s.y + Math.sin(ang) * len };
        if (f === "handN") p.handN = nt;
        else p.handF = nt;
      } else if (f === "footN" || f === "footF") {
        const s = f === "footN" ? r.hipN : r.hipF;
        const t = f === "footN" ? p.footN : p.footF;
        const dx = t.x - s.x;
        const dy = t.y - s.y;
        const ang = Math.atan2(dy, dx) + d;
        const len = Math.hypot(dx, dy);
        const nt = { x: s.x + Math.cos(ang) * len, y: Math.max(0, s.y + Math.sin(ang) * len) };
        if (f === "footN") p.footN = nt;
        else p.footF = nt;
      } else if (f === "torso") {
        p.lean = clamp(p.lean + d, -0.62, 0.8);
      } else {
        p.crouch = clamp(p.crouch - d * 0.6, 0, 1);
      }
    });
  };



  const toggleHand = (f: Focus) => {
    edit((p) => {
      if (f === "handN") p.kindN = p.kindN === "fist" ? "palm" : "fist";
      else if (f === "handF") p.kindF = p.kindF === "fist" ? "palm" : "fist";
      else {
        p.kindN = p.kindN === "fist" ? "palm" : "fist";
        p.kindF = p.kindF === "fist" ? "palm" : "fist";
      }
    });
    play("block", 4);
  };

  const onContextMenu = (e: React.MouseEvent) => {
    e.preventDefault();
    if (phaseRef.current !== "plan") return;
    const { wx, wy } = toWorld(e as unknown as PointerEvent);
    const h = hitTest(planRef.current, sim.f[0].facing, wx, wy);
    toggleHand(h === "handN" || h === "handF" ? h : focusRef.current);
  };

  // ── preview & commit ────────────────────────────────────────────────────
  const doPreview = useCallback(() => {
    const s = simRef.current!;
    if (phaseRef.current !== "plan") return;
    initAudio();
    play("whoosh", 4);
    const plan: Plan = { pose: clonePose(planRef.current), tempo: tempoRef.current, tag: tagOf(s.f[0].cur, planRef.current) };
    const res = runPreview(s, plan, { reveal: artRef.current === "ghost", emptyMind: artRef.current === "empty" });
    setPrevRes(res);
    go("preview");
  }, []);

  const backToPlan = useCallback(() => {
    if (phaseRef.current !== "preview") return;
    setPrevRes(null);
    go("plan");
  }, []);

  const commit = useCallback(() => {
    const s = simRef.current!;
    if (phaseRef.current !== "plan" && phaseRef.current !== "preview") return;
    initAudio();

    s.active = { p: new Set(), o: new Set() };
    s.decoy = null;
    const art = artRef.current;
    armedArtRef.current = art;
    if (art && (chargesRef.current[art] ?? 0) > 0) {
      s.active.p.add(art);
      setCharges((c) => ({ ...c, [art]: Math.max(0, c[art] - 1) }));
    }

    const pPlan: Plan = { pose: clonePose(planRef.current), tempo: tempoRef.current, tag: tagOf(s.f[0].cur, planRef.current) };
    let oPlan = aiPlanRef.current ?? { pose: clonePose(s.f[1].cur), tempo: 0.9, tag: "hold" as const };
    if (art === "afterimage") {
      s.decoy = { x: planRef.current.x + s.f[0].facing * 74, y: 110 };
      oPlan = planAI(s, s.f[1], s.f[0], opp, () => Math.random());
    }
    beginTurn(s, pPlan, oPlan);
    syncHud();
    setPrevRes(null);
    setActiveArt(null);
    artRef.current = null;
    aiPlanRef.current = null;
    go("resolve");
  }, [opp, syncHud]);

  commitRef.current = commit;

  // turn timer
  useEffect(() => {
    if (phase !== "plan" || turnLimit === 0) return;
    const id = setInterval(() => {
      setTime((t) => {
        if (t <= 0.1) {
          commitRef.current();
          return 0;
        }
        return +(t - 0.1).toFixed(1);
      });
    }, 100);
    return () => clearInterval(id);
  }, [phase, turnLimit]);

  // art selection
  const chooseArt = (id: string) => {
    const ph = phaseRef.current;
    if (ph !== "plan" && ph !== "preview") return;
    if (!unlocked.includes(id)) return;
    if ((chargesRef.current[id] ?? 0) <= 0) return;
    initAudio();
    const next = activeArt === id ? null : id;
    setActiveArt(next);
    artRef.current = next;
    play("parry", 5);
    if (ph === "preview") backToPlan();
  };

  // ── keyboard ────────────────────────────────────────────────────────────
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement)?.tagName;
      if (tag === "INPUT" || tag === "TEXTAREA") return;
      const ph = phaseRef.current;
      const k = e.key;
      if (k === "Tab") {
        e.preventDefault();
        const i = FOCUS_ORDER.indexOf(focusRef.current);
        const n = (i + (e.shiftKey ? -1 : 1) + FOCUS_ORDER.length) % FOCUS_ORDER.length;
        setF(FOCUS_ORDER[n]);
        return;
      }
      if (k === " " || k === "Spacebar") {
        e.preventDefault();
        if (ph === "plan") doPreview();
        else if (ph === "preview") backToPlan();
        return;
      }
      if (k === "Enter") {
        e.preventDefault();
        if (ph === "second") {
          const s = simRef.current!;
          const f = s.f[0];
          f.from = clonePose(f.cur);
          f.p = 0;
          f.target = clonePose(planRef.current);
          f.dur = 24;
          go("resolve");
        } else commitRef.current();
        return;
      }
      if (k === "Escape") {
        if (ph === "preview") backToPlan();
        return;
      }
      if (/^[1-9]$/.test(k)) {
        const list = ARTS.filter((a) => unlocked.includes(a.id));
        const a = list[Number(k) - 1];
        if (a) chooseArt(a.id);
        return;
      }
      if (ph !== "plan" && ph !== "second") return;
      const f = focusRef.current;
      const stepPx = e.shiftKey ? 14 : 6;
      const map: Record<string, [number, number]> = {
        ArrowLeft: [-stepPx, 0],
        ArrowRight: [stepPx, 0],
        ArrowUp: [0, stepPx],
        ArrowDown: [0, -stepPx],
        a: [-stepPx, 0],
        d: [stepPx, 0],
        w: [0, stepPx],
        s: [0, -stepPx],
        A: [-stepPx, 0],
        D: [stepPx, 0],
        W: [0, stepPx],
        S: [0, -stepPx],
      };
      if (map[k]) {
        e.preventDefault();
        const [dx, dy] = map[k];
        const facing = sim.f[0].facing;
        edit((p) => {
          if (f === "root") {
            p.x += dx * facing * 1.6;
            p.crouch = clamp(p.crouch - dy * 0.016, 0, 1);
          }
          else if (f === "torso") {
            p.lean = clamp(p.lean + dx * 0.012, -0.62, 0.8);
            p.crouch = clamp(p.crouch - dy * 0.014, 0, 1);
          } else if (f === "handN") p.handN = { x: p.handN.x + dx, y: p.handN.y + dy };
          else if (f === "handF") p.handF = { x: p.handF.x + dx, y: p.handF.y + dy };
          else if (f === "footN") p.footN = { x: p.footN.x + dx, y: Math.max(0, p.footN.y + dy) };
          else p.footF = { x: p.footF.x + dx, y: Math.max(0, p.footF.y + dy) };
        });
        return;
      }
      if (k === "f" || k === "F" || k === "h" || k === "H") {
        e.preventDefault();
        toggleHand(f);
      }
      if (k === "r" || k === "R") {
        e.preventDefault();
        edit((p) => {
          const cur = simRef.current!.f[0].cur;
          const keep = { x: p.x, kindN: p.kindN, kindF: p.kindF };
          Object.assign(p, clonePose(cur), keep);
          void rig;
        });
      }
      if (k === "[" ) setTempo((t) => clamp(+(t - 0.1).toFixed(2), 0.6, 1.5));
      if (k === "]") setTempo((t) => clamp(+(t + 0.1).toFixed(2), 0.6, 1.5));
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [doPreview, backToPlan, edit, unlocked, activeArt]);

  useEffect(() => {
    tempoRef.current = tempo;
  }, [tempo]);

  // non-passive wheel so limb rotation can be prevented from scrolling the page
  useEffect(() => {
    const c = canvasRef.current;
    if (!c) return;
    const handler = (e: WheelEvent) => {
      const ph = phaseRef.current;
      if (ph !== "plan" && ph !== "second") return;
      e.preventDefault();
      const d = e.deltaY > 0 ? -0.09 : 0.09;
      rotateFocus(d);
    };
    c.addEventListener("wheel", handler, { passive: false });
    return () => c.removeEventListener("wheel", handler);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // ── main loop ───────────────────────────────────────────────────────────
  useEffect(() => {
    let raf = 0;
    let last = performance.now();
    let acc = 0;
    let frame = 0;

    const resolveTick = () => {
      const s = simRef.current!;
      const before = [s.f[0].p, s.f[1].p];
      step(s, { sandbox: mode === "sandbox", training: mode === "training" });

      for (const ev of s.events) {
        fx.current.labels.push({ ev, age: 0 });
        fx.current.flashes.push({ x: ev.x, y: ev.y, t: 0, heavy: ev.heavy });
        if (ev.kind === "hit") {
          spawnImpact(fx.current.parts, ev.x, ev.y, ev.heavy, ev.side === 0 ? -1 : 1);
          play("hit", ev.power);
        } else if (ev.kind === "block") {
          spawnImpact(fx.current.parts, ev.x, ev.y, false, 0);
          play("block", ev.power);
        } else if (ev.kind === "parry") play("parry", ev.power);
        else if (ev.kind === "clash") {
          spawnImpact(fx.current.parts, ev.x, ev.y, true, 0);
          play("clash", ev.power);
        } else if (ev.kind === "stumble") play("stumble", ev.power);
        else if (ev.kind === "fall") {
          spawnDust(fx.current.parts, ev.x, 4, 1);
          spawnDust(fx.current.parts, ev.x, 4, -1);
          play("fall", ev.power);
        } else if (ev.kind === "break") play("break", ev.power);
        else if (ev.kind === "push") play("block", ev.power);
      }

      // footfall dust
      for (let i = 0; i < 2; i++) {
        const f = s.f[i];
        if (before[i] < 0.55 && f.p >= 0.55) {
          const moved = Math.abs(f.target.footF.x - f.from.footF.x) + Math.abs(f.target.footN.x - f.from.footN.x);
          if (moved > 16) spawnDust(fx.current.parts, f.cur.x - f.facing * 12, 3, f.facing);
        }
        prevP.current[i] = f.p;
      }

      // second thought
      if (armedArtRef.current === "second" && !s.secondThoughtUsed && s.f[0].p > 0.55 && s.f[1].p > 0.2) {
        s.secondThoughtUsed = true;
        planRef.current = clonePose(s.f[0].target);
        bump();
        go("second");
        return;
      }

      if (s.winner !== null) {
        go("ko");
        return;
      }
      if (s.ended) {
        s.ended = false;
        startPlan();
      }
    };

    const loop = (t: number) => {
      const dt = Math.min(80, t - last);
      last = t;
      acc += dt;
      const c = canvasRef.current;
      const ph = phaseRef.current;

      if (ph === "resolve") {
        while (acc >= 16.666) {
          acc -= 16.666;
          if (phaseRef.current !== "resolve") break;
          resolveTick();
        }
      } else acc = 0;

      if (c) {
        const w = c.clientWidth;
        const h = c.clientHeight;
        const dpr = Math.min(2, window.devicePixelRatio || 1);
        if (c.width !== Math.round(w * dpr) || c.height !== Math.round(h * dpr)) {
          c.width = Math.round(w * dpr);
          c.height = Math.round(h * dpr);
        }
        const ctx = c.getContext("2d");
        if (ctx && w > 0 && h > 0) {
          ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
          const s = simRef.current!;
          const planning = ph === "plan" || ph === "preview" || ph === "second";
          const anchor = planning ? planRef.current : s.f[0].cur;
          const cam = makeCam(w, h, anchor, s.f[1].cur, ph === "preview" ? 1.03 : 1);
          cam.shake = s.shake;
          camRef.current = cam;

          drawStage(ctx, w, h, cam, bg.current, paper.current);

          ctx.save();
          if (s.shake > 0) ctx.translate((Math.random() - 0.5) * s.shake * 3.4, (Math.random() - 0.5) * s.shake * 2.4);

          const [P, O] = s.f;
          // sash tails behind the bodies
          drawStrand(ctx, P.cloth, cam, 17, P.accent, 0.5);
          drawStrand(ctx, O.cloth, cam, 17, O.accent, 0.5);

          if (ph !== "replay") {
            drawFighter(ctx, O.cur, O.facing, cam, { mode: "solid", accent: opp.accent, flash: O.flash });
            drawStrand(ctx, O.hair, cam, 9, COLORS.INK, 0.6);
            drawFighter(ctx, P.cur, P.facing, cam, {
              mode: "solid",
              accent: P.accent,
              flash: P.flash,
              alpha: planning ? 0.42 : 1,
            });
            drawStrand(ctx, P.hair, cam, 9, COLORS.INK, 0.6);
          }

          if (planning) {
            // opponent's visible stance is all you get
            if (activeArt === "ghost" && aiPlanRef.current) {
              drawFighter(ctx, aiPlanRef.current.pose, O.facing, cam, {
                mode: "ghost",
                ghostOf: "enemy",
                accent: COLORS.INDIGO,
                alpha: 0.5,
              });
            }
            drawFighter(ctx, planRef.current, P.facing, cam, {
              mode: "ghost",
              ghostOf: "player",
              accent: COLORS.CINNABAR,
              alpha: 0.8,
            });
            drawHandles(ctx, planRef.current, P.facing, cam, ph !== "preview" ? focus : null, COLORS.CINNABAR);

            // root travel guide
            ctx.save();
            ctx.strokeStyle = "rgba(193,39,45,0.5)";
            ctx.setLineDash([4, 5]);
            ctx.lineWidth = 1.4;
            ctx.beginPath();
            ctx.moveTo((P.cur.x - cam.cx) * cam.z + w / 2, cam.gy - 2);
            ctx.lineTo((planRef.current.x - cam.cx) * cam.z + w / 2, cam.gy - 2);
            ctx.stroke();
            ctx.restore();

            if (ph === "preview" && prevRes) {
              drawTrajectories(ctx, prevRes.samples, P.facing, cam, COLORS.CINNABAR);
              drawContacts(ctx, prevRes.contacts, cam, COLORS.CINNABAR);
            }
          }

          if (mode === "training" || mode === "sandbox") drawDebug(ctx, s, cam);
          drawFighterLabel(ctx, O, cam, opp.title);
          drawFighterLabel(ctx, P, cam, FOCUS_LABEL[focus]);

          // effects
          for (let i = fx.current.flashes.length - 1; i >= 0; i--) {
            const fl = fx.current.flashes[i];
            fl.t += 0.05;
            if (fl.t > 1) fx.current.flashes.splice(i, 1);
            else drawImpactFlash(ctx, fl.x, fl.y, cam, fl.t, fl.heavy);
          }
          drawParticles(ctx, fx.current.parts, cam);
          stepParticles(fx.current.parts);
          for (let i = fx.current.labels.length - 1; i >= 0; i--) {
            const l = fx.current.labels[i];
            l.age += 1;
            if (l.age > 46) fx.current.labels.splice(i, 1);
            else drawEventLabel(ctx, l.ev, cam, l.age);
          }
          ctx.restore();

          if (frame % 4 === 0 && ph === "resolve") syncHud();
        }
      }
      frame++;
      raf = requestAnimationFrame(loop);
    };
    raf = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(raf);
  }, [mode, opp, prevRes, activeArt, focus, syncHud, startPlan]);

  const endAndWatch = () => {
    const s = simRef.current!;
    s.winner = s.winner ?? (s.f[0].hp > s.f[1].hp ? 0 : s.f[1].hp > s.f[0].hp ? 1 : null);
    go("ko");
  };

  useEffect(() => {
    if (phase !== "ko") return;
    const id = setTimeout(() => onFinished(simRef.current!), 2000);
    return () => clearTimeout(id);
  }, [phase, onFinished, sim]);

  if (phase === "replay") return null;

  const plan = planRef.current;
  const canPlan = phase === "plan" || phase === "second";
  const artObj = activeArt ? ARTS.find((a) => a.id === activeArt) : null;

  return (
    <div className="flex h-full w-full flex-col-reverse overflow-y-auto bg-paper lg:flex-row lg:overflow-hidden" data-plan-ver={planVer}>
      {/* ── instrument rail ───────────────────────────────────────────── */}
      <aside className="relative flex w-full shrink-0 flex-col gap-4 overflow-y-auto border-ink/25 bg-paper/85 px-4 py-4 lg:h-full lg:w-[306px] lg:border-r">
        <div className="pointer-events-none absolute right-1 top-4 hidden lg:block">
          <span className="vtext font-display text-[26px] font-900 leading-none tracking-[0.2em] text-ink/12">節奏戰鬥</span>
        </div>

        <div className="flex items-end justify-between border-b border-ink/25 pb-2">
          <div>
            <div className="font-hud text-[10px] uppercase tracking-[0.34em] text-ink-3">Turn</div>
            <div className="font-display text-3xl font-900 leading-none tnum">{String(hud.turn).padStart(2, "0")}</div>
          </div>
          <div className="text-right">
            <div className="font-hud text-[10px] uppercase tracking-[0.28em] text-ink-3">Focus</div>
            <div className="font-hud text-[13px] font-700 uppercase tracking-[0.16em] text-cinnabar">{FOCUS_LABEL[focus]}</div>
          </div>
        </div>

        <Stat label="HEALTH" cn="命" v={hud.hp} color="#C1272D" />
        <Stat label="STAMINA" cn="氣" v={hud.sta} color="#2E4A6B" />
        <Stat label="BALANCE" cn="勢" v={hud.bal} color="#3A342C" fray />
        <Stat label="GUARD" cn="守" v={hud.grd} color="#6B6151" fray />

        <div className="border-t border-ink/25 pt-3">
          <div className="mb-2 flex items-baseline justify-between">
            <span className="font-hud text-[10px] uppercase tracking-[0.3em] text-ink-3">Opponent</span>
            <span className="font-hud text-[10px] uppercase tracking-[0.2em] text-ink-3 tnum">{opp.en}</span>
          </div>
          <Stat label="HEALTH" cn="命" v={hud.oHp} color="#C1272D" compact />
          <Stat label="GUARD" cn="守" v={hud.oGrd} color="#6B6151" compact fray />
          {(mode === "training" || mode === "sandbox") && <Stat label="BALANCE" cn="勢" v={hud.oBal} color="#3A342C" compact />}
        </div>

        {/* hands */}
        <div className="border-t border-ink/25 pt-3">
          <div className="mb-2 font-hud text-[10px] uppercase tracking-[0.3em] text-ink-3">Hands</div>
          <div className="grid grid-cols-2 gap-2">
            <HandBtn kind={plan.kindN} label="LEAD" active={focus === "handN"} onClick={() => { setF("handN"); toggleHand("handN"); }} />
            <HandBtn kind={plan.kindF} label="REAR" active={focus === "handF"} onClick={() => { setF("handF"); toggleHand("handF"); }} />
          </div>
        </div>

        {/* arts */}
        <div className="border-t border-ink/25 pt-3">
          <div className="mb-2 flex items-baseline justify-between">
            <span className="font-hud text-[10px] uppercase tracking-[0.3em] text-ink-3">Arts 絕技</span>
            <span className="font-hud text-[10px] tracking-[0.2em] text-ink-3">{unlocked.length}/{ARTS.length}</span>
          </div>
          <div className="grid grid-cols-6 gap-1.5">
            {ARTS.map((a, i) => {
              const has = unlocked.includes(a.id);
              const left = charges[a.id] ?? 0;
              const on = activeArt === a.id;
              const usable = has && left > 0 && canPlan;
              return (
                <button
                  key={a.id}
                  title={`${a.cn} ${a.en} — ${a.desc}`}
                  onClick={() => chooseArt(a.id)}
                  disabled={!usable}
                  className={`relative grid aspect-square place-items-center border font-display text-[15px] font-900 transition-all ${
                    on
                      ? "border-cinnabar bg-cinnabar text-paper"
                      : usable
                        ? "border-ink/35 bg-paper text-ink hover:border-cinnabar hover:text-cinnabar"
                        : "border-ink/15 bg-transparent text-ink/25"
                  }`}
                >
                  {a.cn.slice(0, 1)}
                  <span className="absolute bottom-0 right-0.5 font-hud text-[8px] leading-none tnum opacity-70">
                    {has ? left : "—"}
                  </span>
                  <span className="absolute -top-0.5 left-0.5 font-hud text-[7px] leading-none opacity-55">{i + 1}</span>
                </button>
              );
            })}
          </div>
          <p className="mt-2 min-h-[46px] font-hud text-[12px] leading-snug text-ink-3">
            {artObj ? (
              <span>
                <b className="font-display text-cinnabar">{artObj.cn}</b>{" "}
                <b className="uppercase tracking-[0.12em] text-ink">{artObj.en}</b> — {artObj.desc}
              </span>
            ) : (
              <span>Press a number to arm an art for this turn. Arts change information and movement, never damage.</span>
            )}
          </p>
        </div>

        <div className="mt-auto border-t border-ink/25 pt-3 font-hud text-[11px] leading-relaxed text-ink-3">
          <div className="flex justify-between"><span>TAB</span><span className="text-ink">cycle body part</span></div>
          <div className="flex justify-between"><span>DRAG / WASD / ←↑→↓</span><span className="text-ink">move it</span></div>
          <div className="flex justify-between"><span>WHEEL</span><span className="text-ink">rotate limb</span></div>
          <div className="flex justify-between"><span>RIGHT-CLICK / F</span><span className="text-ink">fist ⇄ palm</span></div>
          <div className="flex justify-between"><span>[ &amp; ]</span><span className="text-ink">tempo {tempo.toFixed(2)}</span></div>
          <div className="flex justify-between"><span>R</span><span className="text-ink">reset pose</span></div>
          {mode === "training" && (
            <button
              onClick={onTogglePassive}
              className="mt-2 w-full border border-ink/40 py-1.5 font-hud text-[11px] font-700 uppercase tracking-[0.2em] hover:bg-ink hover:text-paper"
            >
              Partner: {trainingPassive ? "Passive" : "Resisting"}
            </button>
          )}
        </div>
      </aside>

      {/* ── stage ─────────────────────────────────────────────────────── */}
      <main className="relative flex min-h-0 flex-1 flex-col">
        {/* full-bleed top band */}
        <div className="relative z-10 flex items-end justify-between gap-4 border-b border-ink/25 bg-paper/70 px-4 pb-1.5 pt-2">
          <div className="flex items-baseline gap-3">
            <span className="font-display text-[clamp(28px,4.4vw,52px)] font-900 leading-none tracking-tight">
              {phase === "plan" ? "布陣" : phase === "preview" ? "觀想" : phase === "resolve" ? "交手" : phase === "second" ? "回念" : "終"}
            </span>
            <span className="font-hud text-[clamp(11px,1.5vw,15px)] font-700 uppercase tracking-[0.4em] text-cinnabar">
              {phase === "plan" ? "Plan" : phase === "preview" ? "Preview" : phase === "resolve" ? "Engaged" : phase === "second" ? "Second thought" : "Finished"}
            </span>
          </div>
          <div className="flex items-center gap-4">
            {turnLimit > 0 && (
              <span className="font-hud text-[13px] font-700 tnum tracking-[0.1em]">
                {time.toFixed(1)}s
              </span>
            )}
            <span className="hidden font-hud text-[11px] uppercase tracking-[0.3em] text-ink-3 sm:inline">
              {opp.cn} {opp.en}
            </span>
          </div>
        </div>
        {turnLimit > 0 && (
          <div className="h-[3px] w-full bg-ink/10">
            <div
              className="h-full bg-cinnabar transition-[width] duration-100 ease-linear"
              style={{ width: `${turnLimit ? (time / turnLimit) * 100 : 100}%` }}
            />
          </div>
        )}

        <div className="relative min-h-[46vh] flex-1">
          <canvas
            ref={canvasRef}
            className={`absolute inset-0 h-full w-full touch-none ${phase === "preview" ? "sepia-ghost" : ""}`}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            onContextMenu={onContextMenu}
          />

          {/* preview banner */}
          {phase === "preview" && prevRes && (
            <div className="pointer-events-none absolute inset-x-0 top-0 flex flex-col items-center gap-2 p-3">
              <div className="pointer-events-auto flex flex-wrap items-center justify-center gap-3 bg-ink/90 px-4 py-2">
                <span className="font-hud text-[13px] font-700 uppercase tracking-[0.3em] text-paper">
                  Preview — nothing committed
                </span>
                <span className="font-hud text-[12px] tracking-[0.14em] text-paper-3">
                  reach {prevRes.reach.toFixed(0)} · peak hand speed {prevRes.maxSpeed.toFixed(1)} · step{" "}
                  {prevRes.pushForward >= 0 ? "+" : ""}
                  {prevRes.pushForward.toFixed(0)}
                </span>
              </div>
              <div className="pointer-events-auto flex flex-wrap justify-center gap-2">
                {prevRes.contacts.length > 0 ? (
                  prevRes.contacts.map((c, i) => (
                    <span key={i} className="border border-cinnabar bg-paper px-2 py-0.5 font-hud text-[11px] font-700 uppercase tracking-[0.16em] text-cinnabar">
                      {c.limb.replace("hand", "fist").replace("foot", "foot")} → {c.zone}
                    </span>
                  ))
                ) : (
                  <span className="border border-ink/40 bg-paper px-2 py-0.5 font-hud text-[11px] font-700 uppercase tracking-[0.16em] text-ink-3">
                    No contact found — this line misses
                  </span>
                )}
              </div>
              <div className="pointer-events-auto flex flex-wrap justify-center gap-2">
                {prevRes.countered && (
                  <span className="bg-indigo-ink px-2 py-0.5 font-hud text-[11px] font-700 uppercase tracking-[0.16em] text-paper">
                    Their stance is primed to counter this
                  </span>
                )}
                {(prevRes.vulnerable.head || prevRes.vulnerable.torso) && (
                  <span className="bg-cinnabar px-2 py-0.5 font-hud text-[11px] font-700 uppercase tracking-[0.16em] text-paper">
                    You finish open — {prevRes.vulnerable.head ? "head" : ""} {prevRes.vulnerable.head && prevRes.vulnerable.torso ? "+" : ""} {prevRes.vulnerable.torso ? "body" : ""} exposed
                  </span>
                )}
                {activeArt === "empty" && (
                  <span className="border border-ink bg-paper px-2 py-0.5 font-hud text-[11px] font-700 uppercase tracking-[0.16em]">
                    Empty Mind: they are holding a {sim.f[1].cur.kindN === "palm" ? "palm" : "fist"} guard on the centreline
                  </span>
                )}
              </div>
            </div>
          )}

          {phase === "second" && (
            <div className="absolute inset-0 grid place-items-center bg-paper/45">
              <div className="stamp max-w-md border-2 border-cinnabar bg-paper px-6 py-5 text-center shadow-xl">
                <div className="font-display text-4xl font-900 text-cinnabar">回念</div>
                <div className="mt-1 font-hud text-[13px] font-700 uppercase tracking-[0.34em]">Second Thought</div>
                <p className="mt-2 font-hud text-[14px] leading-snug text-ink-2">
                  Both bodies are already in motion. Drag your ghost to shift the line — once.
                </p>
                <button
                  onClick={() => {
                    const s = simRef.current!;
                    const f = s.f[0];
                    f.from = clonePose(f.cur);
                    f.p = 0;
                    f.target = clonePose(planRef.current);
                    f.dur = 24;
                    go("resolve");
                  }}
                  className="mt-4 bg-cinnabar px-6 py-3 font-hud text-[13px] font-700 uppercase tracking-[0.3em] text-paper hover:bg-cinnabar-d"
                >
                  Let it fly — Enter
                </button>
              </div>
            </div>
          )}

          {phase === "ko" && (
            <div className="absolute inset-0 grid place-items-center bg-paper/70">
              <div className="stamp text-center">
                <div className="font-display text-[clamp(64px,14vw,168px)] font-900 leading-none text-cinnabar">
                  {sim.winner === 0 ? "勝" : sim.winner === 1 ? "敗" : "和"}
                </div>
                <div className="mt-2 font-hud text-[15px] font-700 uppercase tracking-[0.5em] text-ink">
                  {sim.winner === 0 ? "Victory" : sim.winner === 1 ? "Defeat" : "Draw"}
                </div>
                <div className="mt-1 font-hud text-[12px] uppercase tracking-[0.3em] text-ink-3">Rolling the scroll…</div>
              </div>
            </div>
          )}
        </div>

        {/* bottom bar */}
        <div className="relative z-10 flex flex-wrap items-center gap-3 border-t border-ink/25 bg-paper/85 px-4 py-3">
          <button
            onClick={() => (phase === "preview" ? backToPlan() : doPreview())}
            disabled={phase !== "plan" && phase !== "preview"}
            className="group relative border-2 border-ink px-6 py-3 font-hud text-[13px] font-700 uppercase tracking-[0.28em] transition-colors hover:bg-ink hover:text-paper disabled:opacity-35"
          >
            {phase === "preview" ? "‹ Back to pose" : "Preview move"}
            <span className="ml-3 text-[10px] tracking-[0.1em] opacity-55">SPACE</span>
          </button>

          <button
            onClick={commit}
            disabled={phase !== "plan" && phase !== "preview"}
            className="bg-cinnabar px-8 py-3 font-hud text-[14px] font-700 uppercase tracking-[0.3em] text-paper transition-colors hover:bg-cinnabar-d disabled:opacity-35"
          >
            {phase === "preview" ? "Commit anyway" : "Commit"}
            <span className="ml-3 text-[10px] tracking-[0.1em] opacity-70">ENTER</span>
          </button>

          <div className="ml-auto flex items-center gap-3">
            {artObj && (
              <span className="hidden border border-cinnabar px-2 py-1 font-hud text-[11px] font-700 uppercase tracking-[0.18em] text-cinnabar sm:inline">
                {artObj.en} armed
              </span>
            )}
            <button
              onClick={endAndWatch}
              disabled={phase === "ko" || sim.log.length === 0}
              className="border border-ink/40 px-4 py-3 font-hud text-[12px] font-700 uppercase tracking-[0.24em] transition-colors hover:bg-ink hover:text-paper disabled:opacity-35"
            >
              End &amp; watch replay
            </button>
            <button
              onClick={onExit}
              className="border border-ink/40 px-4 py-3 font-hud text-[12px] font-700 uppercase tracking-[0.24em] transition-colors hover:bg-ink hover:text-paper"
            >
              Leave
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}

function Stat({ label, cn, v, color, compact, fray }: { label: string; cn: string; v: number; color: string; compact?: boolean; fray?: boolean }) {
  const pct = clamp(v, 0, 100);
  return (
    <div className={`flex items-center gap-2 ${compact ? "mb-1" : "mb-1.5"}`}>
      <span className={`grid ${compact ? "h-4 w-4" : "h-5 w-5"} shrink-0 place-items-center font-display text-[11px] font-900`} style={{ background: color, color: "#E8DFCE" }}>
        {cn}
      </span>
      <span className={`w-[54px] shrink-0 font-hud ${compact ? "text-[9px]" : "text-[10px]"} uppercase tracking-[0.18em] text-ink-3`}>{label}</span>
      <span className="relative h-[9px] flex-1 bg-ink/12">
        <span
          className="absolute inset-y-0 left-0 transition-[width] duration-300"
          style={{
            width: `${pct}%`,
            background: color,
            clipPath: fray
              ? "polygon(0 0,100% 0,99% 22%,100% 44%,98% 66%,100% 84%,99% 100%,0 100%)"
              : undefined,
          }}
        />
        {fray && (
          <span className="absolute inset-y-0 right-0 w-px bg-ink/25" />
        )}
      </span>
      <span className={`w-7 shrink-0 text-right font-hud ${compact ? "text-[10px]" : "text-[11px]"} font-700 tnum text-ink-2`}>{Math.round(v)}</span>
    </div>
  );
}

function HandBtn({
  kind,
  label,
  active,
  onClick,
}: {
  kind: "fist" | "palm";
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center justify-between gap-2 border px-2 py-2 transition-colors ${
        active ? "border-cinnabar bg-cinnabar/10" : "border-ink/30 hover:border-ink"
      }`}
    >
      <span className="font-hud text-[10px] uppercase tracking-[0.2em] text-ink-3">{label}</span>
      <span className="flex items-center gap-1.5">
        <svg width="16" height="16" viewBox="0 0 16 16" aria-hidden>
          {kind === "fist" ? (
            <g fill="#1B1815">
              <rect x="2" y="4.5" width="10" height="7" rx="1.4" />
              <rect x="11" y="6" width="3.4" height="4" rx="1" />
              <rect x="3" y="5.6" width="8" height="1.4" fill="#E8DFCE" opacity="0.5" />
            </g>
          ) : (
            <g fill="#2E4A6B">
              <rect x="3" y="3.4" width="7.5" height="9.2" rx="1.2" />
              <rect x="10" y="4.4" width="3.2" height="6.6" rx="1.4" />
              <path d="M10.6 6.2h2.4M10.6 8h2.4" stroke="#E8DFCE" strokeWidth="1" />
            </g>
          )}
        </svg>
        <span className="font-hud text-[12px] font-700 uppercase tracking-[0.14em]">{kind}</span>
      </span>
    </button>
  );
}


